package com.example.data.remote

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@Serializable
data class OpenMeteoResponse(
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    @SerialName("current_weather") val currentWeather: CurrentWeather? = null,
    val daily: DailyForecast? = null
)

@Serializable
data class CurrentWeather(
    val temperature: Double = 0.0,
    val windspeed: Double = 0.0,
    val weathercode: Int = 0,
    @SerialName("is_day") val isDay: Int = 1
)

@Serializable
data class DailyForecast(
    @SerialName("temperature_2m_max") val maxTemps: List<Double> = emptyList(),
    @SerialName("temperature_2m_min") val minTemps: List<Double> = emptyList(),
    @SerialName("precipitation_probability_max") val rainChance: List<Int> = emptyList()
)

@Serializable
data class GeoSearchResponse(
    val results: List<GeoCityResult>? = null
)

@Serializable
data class GeoCityResult(
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val country: String? = null,
    val admin1: String? = null
)

data class WeatherSnapshot(
    val cityName: String,
    val region: String,
    val temperatureC: Double,
    val highC: Double,
    val lowC: Double,
    val windKmh: Double,
    val rainProbability: Int,
    val conditionHindi: String,
    val conditionEnglish: String,
    val emoji: String
)

interface OpenMeteoService {
    @GET("v1/forecast?current_weather=true&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto")
    suspend fun getForecast(
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double
    ): OpenMeteoResponse
}

interface GeoCodingService {
    @GET("v1/search?count=5&language=en&format=json")
    suspend fun searchCity(
        @Query("name") name: String
    ): GeoSearchResponse
}

object WeatherNetworkClient {
    private val json = Json {
        ignoreUnknownKeys = true
        explicitNulls = false
    }

    private val okHttp = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    val weatherService: OpenMeteoService by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.open-meteo.com/")
            .client(okHttp)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
            .create(OpenMeteoService::class.java)
    }

    val geoService: GeoCodingService by lazy {
        Retrofit.Builder()
            .baseUrl("https://geocoding-api.open-meteo.com/")
            .client(okHttp)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
            .create(GeoCodingService::class.java)
    }

    fun decodeWeatherCode(code: Int): Triple<String, String, String> {
        return when (code) {
            0 -> Triple("साफ़ आसमान", "Clear Sky", "☀️")
            1, 2 -> Triple("हल्के बादल", "Partly Cloudy", "⛅")
            3 -> Triple("घने बादल", "Overcast", "☁️")
            45, 48 -> Triple("कोहरा / धुंध", "Foggy", "🌫️")
            51, 53, 55 -> Triple("हल्की बूंदाबांदी", "Light Drizzle", "🌦️")
            61, 63, 65, 80, 81, 82 -> Triple("बारिश", "Rain Showers", "🌧️")
            71, 73, 75 -> Triple("बर्फ़बारी", "Snowfall", "❄️")
            95, 96, 99 -> Triple("आंधी और गरज", "Thunderstorm", "⛈️")
            else -> Triple("सामान्य मौसम", "Moderate", "🌤️")
        }
    }
}
