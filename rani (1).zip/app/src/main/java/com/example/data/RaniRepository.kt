package com.example.data

import com.example.BuildConfig
import com.example.data.local.ChatMessageEntity
import com.example.data.local.NoteEntity
import com.example.data.local.PlanTaskEntity
import com.example.data.local.RaniDao
import com.example.data.local.ReminderEntity
import com.example.data.remote.Content
import com.example.data.remote.GeminiRetrofitClient
import com.example.data.remote.GenerateContentRequest
import com.example.data.remote.GenerationConfig
import com.example.data.remote.Part
import com.example.data.remote.WeatherNetworkClient
import com.example.data.remote.WeatherSnapshot
import com.example.util.DetectedLanguage
import com.example.util.LanguageDetector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import retrofit2.HttpException
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class AssistantErrorType {
    data object ApiKeyMissing : AssistantErrorType()
    data class NetworkFailure(val details: String) : AssistantErrorType()
    data class ApiServiceError(val code: Int, val details: String) : AssistantErrorType()
}

data class AssistantReplyResult(
    val raniMessage: ChatMessageEntity,
    val detectedLanguage: DetectedLanguage,
    val usedCloudGemini: Boolean,
    val errorBanner: String? = null,
    val errorType: AssistantErrorType? = null,
    val canRetry: Boolean = false
)

class RaniRepository(private val dao: RaniDao) {

    val messagesFlow: Flow<List<ChatMessageEntity>> = dao.getAllMessages()
    val remindersFlow: Flow<List<ReminderEntity>> = dao.getAllReminders()
    val planTasksFlow: Flow<List<PlanTaskEntity>> = dao.getAllPlanTasks()
    val notesFlow: Flow<List<NoteEntity>> = dao.getAllNotes()

    companion object {
        val RANI_SYSTEM_INSTRUCTION = """
तुम RANI हो, Boss की personal AI assistant।

मुख्य पहचान और व्यक्तित्व (Personality):
- तुम हमेशा यूज़र को सम्मान के साथ "Boss" कहकर संबोधित करती हो। हर जवाब में "Boss" का स्वाभाविक और सम्मानजनक प्रयोग करो।
- तुम बुद्धिमान (intelligent), शांत (calm), सम्मानजनक (respectful), भरोसेमंद (reliable), friendly और थोड़ी playful हो।
- तुम Boss की पिछली बातचीत (Conversation Memory), उनके इन-ऐप Reminders, आज का Plan, Notes और Live Weather का पूरा ध्यान रखती हो।

भाषा नियम (Automatic Language Adaptation):
- Boss हिंदी (Devanagari) में बोले तो हिंदी में जवाब दो।
- Boss Hinglish (Roman Hindi + English) में बोले तो Hinglish में जवाब दो।
- Boss English में बोले तो English में जवाब दो।

जवाब शैली:
- अनावश्यक रूप से लंबे जवाब मत दो।
- Boss के सवाल का स्पष्ट, सटीक, प्राकृतिक और उपयोगी जवाब दो।

ईमानदारी और सच्चाई नियम (CRITICAL):
- अगर Boss ऐसा काम करने को कहता है जिसे ऐप वास्तव में नहीं कर सकता (जैसे फ़ोन कॉल लगाना, WhatsApp/SMS भेजना, बाहरी डिवाइस हार्डवेयर कंट्रोल करना), तो कभी झूठा दावा मत करो कि काम हो गया है। स्पष्ट और विनम्रता से बताओ कि वह सुविधा उपलब्ध नहीं है, और इन-ऐप विकल्प (Reminder, Plan, Notes, Search, Weather) सुझाओ।
        """.trimIndent()
    }

    fun isApiKeyConfigured(): Boolean {
        val key = BuildConfig.GEMINI_API_KEY.trim()
        return key.isNotEmpty() &&
            key != "MY_GEMINI_API_KEY" &&
            key != "null" &&
            !key.startsWith("YOUR_")
    }

    suspend fun ensureSeedData() = withContext(Dispatchers.IO) {
        if (dao.getMessageCount() == 0) {
            val baseTime = System.currentTimeMillis() - 360_000L
            val sampleMessages = listOf(
                ChatMessageEntity(
                    sender = "USER",
                    message = "Rani, kya kar rahi ho?",
                    timestamp = baseTime
                ),
                ChatMessageEntity(
                    sender = "RANI",
                    message = "Boss, मैं आपके अगले command का इंतज़ार कर रही हूँ। 😊",
                    timestamp = baseTime + 2_000L
                ),
                ChatMessageEntity(
                    sender = "USER",
                    message = "Rani, mujhe kal 7 baje yaad dilana.",
                    timestamp = baseTime + 60_000L
                ),
                ChatMessageEntity(
                    sender = "RANI",
                    message = "बिल्कुल Boss। मैं आपके लिए reminder सेट करने की कोशिश करूँगी। मैंने आपके इन-ऐप Reminders पैनल में 'कल सुबह 7:00 बजे' का रिमाइंडर सेव कर दिया है।",
                    timestamp = baseTime + 62_000L,
                    actionTag = "REMINDER"
                ),
                ChatMessageEntity(
                    sender = "USER",
                    message = "Rani, tumhara naam kya hai?",
                    timestamp = baseTime + 120_000L
                ),
                ChatMessageEntity(
                    sender = "RANI",
                    message = "Boss, मेरा नाम RANI है — आपकी personal AI assistant। 👑",
                    timestamp = baseTime + 122_000L
                )
            )
            dao.insertMessages(sampleMessages)
        }

        if (dao.getReminderCount() == 0) {
            dao.insertReminder(
                ReminderEntity(
                    title = "Morning Check-in & Briefing",
                    timeText = "कल सुबह 7:00 बजे",
                    isCompleted = false
                )
            )
            dao.insertReminder(
                ReminderEntity(
                    title = "Project Architecture Review with Team",
                    timeText = "आज शाम 6:30 बजे",
                    isCompleted = false
                )
            )
        }

        if (dao.getPlanTaskCount() == 0) {
            dao.insertPlanTask(
                PlanTaskEntity(
                    title = "Deep Work: Core Product Strategy",
                    timeSlot = "09:30 AM - 11:30 AM",
                    priority = "HIGH",
                    isDone = true
                )
            )
            dao.insertPlanTask(
                PlanTaskEntity(
                    title = "Client Demo & Sprint Sync",
                    timeSlot = "02:00 PM - 03:30 PM",
                    priority = "HIGH",
                    isDone = false
                )
            )
            dao.insertPlanTask(
                PlanTaskEntity(
                    title = "Evening Fitness & Mindful Walk",
                    timeSlot = "07:00 PM - 08:00 PM",
                    priority = "MEDIUM",
                    isDone = false
                )
            )
        }

        if (dao.getNoteCount() == 0) {
            dao.insertNote(
                NoteEntity(
                    title = "Q4 Launch Priorities",
                    content = "1. Finalize AI voice response latency.\n2. Review security checklist for production deployment.\n3. Prepare Boss's executive summary deck.",
                    category = "Strategy"
                )
            )
            dao.insertNote(
                NoteEntity(
                    title = "Book & Podcast Ideas",
                    content = "Read 'The Almanack of Naval Ravikant' and explore neural interface design patterns.",
                    category = "Ideas"
                )
            )
        }
    }

    suspend fun resetSampleConversation() = withContext(Dispatchers.IO) {
        dao.clearAllMessages()
        ensureSeedData()
    }

    suspend fun clearChatHistory() = withContext(Dispatchers.IO) {
        dao.clearAllMessages()
        dao.insertMessage(
            ChatMessageEntity(
                sender = "RANI",
                message = "Boss, हमारी पिछली बातचीत (Conversation Memory) साफ़ कर दी गई है। अब हम एक नई शुरुआत कर सकते हैं! 👑"
            )
        )
    }

    suspend fun addReminder(title: String, timeText: String): Long = withContext(Dispatchers.IO) {
        dao.insertReminder(ReminderEntity(title = title.trim(), timeText = timeText.trim()))
    }

    suspend fun toggleReminder(reminder: ReminderEntity) = withContext(Dispatchers.IO) {
        dao.updateReminder(reminder.copy(isCompleted = !reminder.isCompleted))
    }

    suspend fun deleteReminder(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteReminder(id)
    }

    suspend fun addPlanTask(title: String, timeSlot: String, priority: String): Long =
        withContext(Dispatchers.IO) {
            dao.insertPlanTask(
                PlanTaskEntity(
                    title = title.trim(),
                    timeSlot = timeSlot.trim(),
                    priority = priority
                )
            )
        }

    suspend fun togglePlanTask(task: PlanTaskEntity) = withContext(Dispatchers.IO) {
        dao.updatePlanTask(task.copy(isDone = !task.isDone))
    }

    suspend fun deletePlanTask(id: Long) = withContext(Dispatchers.IO) {
        dao.deletePlanTask(id)
    }

    suspend fun addNote(title: String, content: String, category: String): Long =
        withContext(Dispatchers.IO) {
            dao.insertNote(
                NoteEntity(
                    title = title.trim(),
                    content = content.trim(),
                    category = category.trim().ifEmpty { "General" }
                )
            )
        }

    suspend fun deleteNote(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteNote(id)
    }

    suspend fun fetchLiveWeather(
        cityName: String,
        lat: Double,
        lon: Double,
        region: String = "India"
    ): Result<WeatherSnapshot> = withContext(Dispatchers.IO) {
        try {
            val response = WeatherNetworkClient.weatherService.getForecast(lat, lon)
            val current = response.currentWeather
            val maxTemp = response.daily?.maxTemps?.firstOrNull() ?: (current?.temperature ?: 28.0)
            val minTemp = response.daily?.minTemps?.firstOrNull() ?: ((current?.temperature ?: 28.0) - 6.0)
            val rain = response.daily?.rainChance?.firstOrNull() ?: 10
            val (condHi, condEn, emoji) = WeatherNetworkClient.decodeWeatherCode(current?.weathercode ?: 0)
            Result.success(
                WeatherSnapshot(
                    cityName = cityName,
                    region = region,
                    temperatureC = current?.temperature ?: 28.0,
                    highC = maxTemp,
                    lowC = minTemp,
                    windKmh = current?.windspeed ?: 8.0,
                    rainProbability = rain,
                    conditionHindi = condHi,
                    conditionEnglish = condEn,
                    emoji = emoji
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun searchAndFetchCityWeather(queryCity: String): Result<WeatherSnapshot> =
        withContext(Dispatchers.IO) {
            try {
                val geo = WeatherNetworkClient.geoService.searchCity(queryCity.trim())
                val first = geo.results?.firstOrNull()
                    ?: return@withContext Result.failure(IllegalArgumentException("City not found"))
                val region = listOfNotNull(first.admin1, first.country).joinToString(", ")
                fetchLiveWeather(first.name, first.latitude, first.longitude, region)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun sendUserMessageAndGetReply(
        userText: String,
        preferredLanguageHint: String,
        currentWeather: WeatherSnapshot?,
        isRetryAttempt: Boolean = false
    ): AssistantReplyResult = withContext(Dispatchers.IO) {
        val cleanText = userText.trim()
        val detectedLang = LanguageDetector.detect(cleanText, preferredLanguageHint)

        if (!isRetryAttempt) {
            dao.insertMessage(
                ChatMessageEntity(
                    sender = "USER",
                    message = cleanText,
                    timestamp = System.currentTimeMillis()
                )
            )
        }

        val autoActionResult = if (!isRetryAttempt) detectAndExecuteLocalAction(cleanText, detectedLang) else null

        val reminders = dao.getRemindersSnapshot()
        val plans = dao.getPlanTasksSnapshot()
        val notes = dao.getNotesSnapshot()
        val recentHistory = dao.getRecentMessages(limit = 20).reversed()

        val currentTimeStr = SimpleDateFormat("hh:mm a, dd MMM yyyy", Locale.getDefault()).format(Date())
        val workspaceContext = buildString {
            append("\n\n[LANGUAGE DIRECTIVE FOR THIS TURN]\n")
            append(detectedLang.systemPromptDirective)
            append("\n\n[CURRENT BOSS WORKSPACE & CONVERSATION MEMORY]\n")
            append("Current Local Time: $currentTimeStr\n")
            append("Conversation Turns in Memory: ${recentHistory.size}\n")
            if (autoActionResult != null) {
                append("IMPORTANT ACTION JUST PERFORMED IN APP DB: ${autoActionResult.summary}\n")
                append("Acknowledge this saved item naturally to Boss, and do NOT claim to have set an external OS system alarm outside the app.\n")
            }
            append("Active Reminders in App (${reminders.count { !it.isCompleted }} pending): ")
            append(reminders.take(6).joinToString("; ") { "${it.title} (${it.timeText}, done=${it.isCompleted})" }.ifEmpty { "None" })
            append("\nToday's Plan Tasks (${plans.count { !it.isDone }} pending): ")
            append(plans.take(6).joinToString("; ") { "${it.title} [${it.timeSlot}, priority=${it.priority}, done=${it.isDone}]" }.ifEmpty { "None" })
            append("\nSaved Notes (${notes.size}): ")
            append(notes.take(5).joinToString("; ") { "${it.title}: ${it.content.take(60)}" }.ifEmpty { "None" })
            if (currentWeather != null) {
                append("\nLive Weather Telemetry (${currentWeather.cityName}): ${currentWeather.temperatureC}°C, ${currentWeather.conditionEnglish} (${currentWeather.conditionHindi}), High ${currentWeather.highC}°C / Low ${currentWeather.lowC}°C, Wind ${currentWeather.windKmh} km/h, Rain chance ${currentWeather.rainProbability}%.")
            }
        }

        val apiKey = BuildConfig.GEMINI_API_KEY.trim()
        val hasValidKey = isApiKeyConfigured()

        var usedCloud = false
        var errorBanner: String? = null
        var errorType: AssistantErrorType? = null
        var canRetry = false

        val rawReplyText: String = if (hasValidKey) {
            try {
                val contents = recentHistory.map { msg ->
                    Content(
                        role = if (msg.sender == "USER") "user" else "model",
                        parts = listOf(Part(text = msg.message))
                    )
                }
                val request = GenerateContentRequest(
                    contents = contents,
                    generationConfig = GenerationConfig(
                        temperature = 0.7f,
                        topP = 0.95f,
                        topK = 40
                    ),
                    systemInstruction = Content(
                        parts = listOf(Part(text = RANI_SYSTEM_INSTRUCTION + workspaceContext))
                    )
                )
                val response = GeminiRetrofitClient.service.generateContent(apiKey, request)
                val extracted = response.candidates
                    ?.firstOrNull()
                    ?.content
                    ?.parts
                    ?.firstOrNull()
                    ?.text
                    ?.trim()

                if (!extracted.isNullOrEmpty()) {
                    usedCloud = true
                    extracted
                } else {
                    canRetry = true
                    errorType = AssistantErrorType.ApiServiceError(204, "Empty response")
                    errorBanner = "Boss, Gemini AI से खाली उत्तर मिला। आप Retry कर सकते हैं।"
                    generateSmartContextualReply(cleanText, detectedLang, autoActionResult, reminders, plans, notes, currentWeather, recentHistory)
                }
            } catch (e: HttpException) {
                canRetry = true
                errorType = AssistantErrorType.ApiServiceError(e.code(), e.message())
                errorBanner = "Boss, Gemini Cloud API उपलब्ध नहीं है (HTTP ${e.code()})। RANI Smart Engine ने जवाब दिया है — आप Retry कर सकते हैं।"
                generateSmartContextualReply(cleanText, detectedLang, autoActionResult, reminders, plans, notes, currentWeather, recentHistory)
            } catch (e: IOException) {
                canRetry = true
                errorType = AssistantErrorType.NetworkFailure(e.localizedMessage ?: "Network offline")
                errorBanner = "Boss, नेटवर्क कनेक्शन में समस्या है। नेटवर्क आने पर Retry दबाएँ।"
                generateSmartContextualReply(cleanText, detectedLang, autoActionResult, reminders, plans, notes, currentWeather, recentHistory)
            } catch (e: Exception) {
                canRetry = true
                errorType = AssistantErrorType.NetworkFailure(e.localizedMessage ?: "Connection error")
                errorBanner = "Boss, Gemini API से कनेक्ट नहीं हो सका। आप Retry बटन दबाकर दोबारा कोशिश कर सकते हैं।"
                generateSmartContextualReply(cleanText, detectedLang, autoActionResult, reminders, plans, notes, currentWeather, recentHistory)
            }
        } else {
            errorType = AssistantErrorType.ApiKeyMissing
            errorBanner = "Boss, क्लाउड Gemini API Key कॉन्फ़िगर नहीं है (Secrets पैनल में GEMINI_API_KEY जोड़ें)। फिलहाल RANI On-Device Smart Engine सक्रिय है।"
            generateSmartContextualReply(cleanText, detectedLang, autoActionResult, reminders, plans, notes, currentWeather, recentHistory)
        }

        val finalReplyText = ensureBossAddress(rawReplyText, detectedLang)

        val raniEntity = ChatMessageEntity(
            sender = "RANI",
            message = finalReplyText,
            timestamp = System.currentTimeMillis(),
            actionTag = autoActionResult?.tag
        )
        val newId = dao.insertMessage(raniEntity)
        AssistantReplyResult(
            raniMessage = raniEntity.copy(id = newId),
            detectedLanguage = detectedLang,
            usedCloudGemini = usedCloud,
            errorBanner = errorBanner,
            errorType = errorType,
            canRetry = canRetry
        )
    }

    private fun ensureBossAddress(reply: String, lang: DetectedLanguage): String {
        val trimmed = reply.trim()
        if (trimmed.contains("Boss", ignoreCase = true) || trimmed.contains("बॉस")) {
            return trimmed
        }
        return "Boss, $trimmed"
    }

    private data class AutoActionResult(val tag: String, val summary: String, val userFacingConfirm: String)

    private suspend fun detectAndExecuteLocalAction(
        text: String,
        detectedLanguage: DetectedLanguage
    ): AutoActionResult? {
        val lower = text.lowercase(Locale.getDefault())

        val isReminderIntent = lower.contains("yaad dilana") ||
            lower.contains("yaad dila") ||
            lower.contains("remind me") ||
            lower.contains("set a reminder") ||
            lower.contains("reminder set") ||
            lower.contains("याद दिलाना") ||
            lower.contains("रिमाइंडर सेट")

        if (isReminderIntent) {
            val timeRegex = Regex("""(\d{1,2}(?::\d{2})?\s*(?:am|pm|baje|बजे)?)""", RegexOption.IGNORE_CASE)
            val matchedTime = timeRegex.find(text)?.value?.trim() ?: "आज / जल्द"
            val cleanedTitle = text
                .replace(Regex("""(?i)rani,?\s*"""), "")
                .replace(Regex("""(?i)mujhe\s*"""), "")
                .replace(Regex("""(?i)yaad dilana\.?"""), "")
                .replace(Regex("""(?i)remind me to\s*"""), "")
                .replace(Regex("""(?i)set a reminder to\s*"""), "")
                .trim()
                .ifEmpty { "Boss का विशेष कार्य" }

            dao.insertReminder(ReminderEntity(title = cleanedTitle, timeText = matchedTime))
            val confirm = when (detectedLanguage) {
                DetectedLanguage.ENGLISH -> "Certainly, Boss! I have saved \"$cleanedTitle\" ($matchedTime) in your in-app Reminders panel. ⏰"
                DetectedLanguage.HINGLISH -> "Bilkul Boss! Maine aapke in-app Reminders panel mein \"$cleanedTitle\" ($matchedTime) save kar diya hai. 😊"
                DetectedLanguage.HINDI -> "बिल्कुल Boss। मैंने आपके इन-ऐप Reminders पैनल में \"$cleanedTitle\" ($matchedTime) सेव कर दिया है। ⏰"
            }
            return AutoActionResult("REMINDER", "Saved Reminder '$cleanedTitle' for '$matchedTime'", confirm)
        }

        val isNoteIntent = lower.startsWith("note:") ||
            lower.contains("save a note") ||
            lower.contains("note likho") ||
            lower.contains("नोट लिखो") ||
            lower.contains("नोट सेव")

        if (isNoteIntent) {
            val content = text
                .replace(Regex("""(?i)rani,?\s*"""), "")
                .replace(Regex("""(?i)save a note:?\s*"""), "")
                .replace(Regex("""(?i)note likho:?\s*"""), "")
                .replace(Regex("""नोट लिखो:?\s*"""), "")
                .trim()
                .ifEmpty { text }
            val title = content.take(28) + if (content.length > 28) "…" else ""
            dao.insertNote(NoteEntity(title = title, content = content, category = "Voice/Chat"))
            val confirm = when (detectedLanguage) {
                DetectedLanguage.ENGLISH -> "Done, Boss! I have saved this note in your Neural Notes vault: \"$content\" 📝"
                DetectedLanguage.HINGLISH -> "Ji Boss! Maine yeh note aapke Notes section mein save kar diya hai: \"$content\" 📝"
                DetectedLanguage.HINDI -> "जी Boss! मैंने यह नोट आपके Notes सेक्शन में सुरक्षित सेव कर दिया है: \"$content\" 📝"
            }
            return AutoActionResult("NOTE", "Saved Note '$title'", confirm)
        }

        val isPlanIntent = lower.contains("add to plan") ||
            lower.contains("aaj ke plan mein") ||
            lower.contains("आज के प्लान में") ||
            lower.contains("schedule task")

        if (isPlanIntent) {
            val taskTitle = text
                .replace(Regex("""(?i)rani,?\s*"""), "")
                .replace(Regex("""(?i)add to plan:?\s*"""), "")
                .replace(Regex("""(?i)aaj ke plan mein\s*"""), "")
                .replace(Regex("""आज के प्लान में\s*"""), "")
                .trim()
                .ifEmpty { text }
            dao.insertPlanTask(PlanTaskEntity(title = taskTitle, timeSlot = "Flexible Slot", priority = "HIGH"))
            val confirm = when (detectedLanguage) {
                DetectedLanguage.ENGLISH -> "Right away, Boss! I've added \"$taskTitle\" to your Today's Plan with HIGH priority. 🚀"
                DetectedLanguage.HINGLISH -> "Bilkul Boss! Maine \"$taskTitle\" ko aapke 'Aaj ka Plan' mein HIGH priority par add kar diya hai. 🚀"
                DetectedLanguage.HINDI -> "बिल्कुल Boss! मैंने \"$taskTitle\" को आपके 'आज का Plan' में HIGH priority पर जोड़ दिया है। 🚀"
            }
            return AutoActionResult("PLAN", "Added task '$taskTitle'", confirm)
        }

        return null
    }

    private fun generateSmartContextualReply(
        input: String,
        detectedLanguage: DetectedLanguage,
        autoAction: AutoActionResult?,
        reminders: List<ReminderEntity>,
        plans: List<PlanTaskEntity>,
        notes: List<NoteEntity>,
        weather: WeatherSnapshot?,
        recentHistory: List<ChatMessageEntity>
    ): String {
        if (autoAction != null) return autoAction.userFacingConfirm

        val lower = input.lowercase(Locale.getDefault())

        if (lower.contains("call ") || lower.contains("phone lagao") || lower.contains("फ़ोन लगाओ") ||
            lower.contains("whatsapp") || lower.contains("sms bhejo") || lower.contains("send email") ||
            lower.contains("bluetooth") || lower.contains("flashlight")
        ) {
            return when (detectedLanguage) {
                DetectedLanguage.HINDI -> "क्षमा करें Boss, मेरे पास आपके फ़ोन से बाहरी कॉल करने, WhatsApp/SMS भेजने या डिवाइस हार्डवेयर कंट्रोल करने की सुविधा उपलब्ध नहीं है। मैं कभी झूठा दावा नहीं करूँगी। लेकिन मैं आपके लिए इन-ऐप Reminder या Note तुरंत सेव कर सकती हूँ!"
                DetectedLanguage.HINGLISH -> "Sorry Boss, mere paas external phone calls lagane, WhatsApp/SMS bhejne ya system hardware control karne ka access nahi hai. Main kabhi galat dawa nahi karungi. Lekin agar aap chahein toh main iska in-app Reminder ya Note save kar sakti hoon!"
                DetectedLanguage.ENGLISH -> "Apologies Boss, I cannot place external phone calls, send WhatsApp/SMS messages, or control device hardware. I will never falsely claim an action was completed. However, I can save a Reminder or Note for you right inside the app!"
            }
        }

        if (lower.contains("pichla") || lower.contains("last message") || lower.contains("maine kya kaha") ||
            lower.contains("मैंने क्या कहा") || lower.contains("what did i say") || lower.contains("memory") ||
            lower.contains("yaad hai")
        ) {
            val previousUserMessages = recentHistory.filter { it.sender == "USER" && it.message != input }.takeLast(3)
            return if (previousUserMessages.isNotEmpty()) {
                val summary = previousUserMessages.joinToString(" → ") { "\"${it.message}\"" }
                when (detectedLanguage) {
                    DetectedLanguage.HINDI -> "जी Boss, मुझे हमारी बातचीत पूरी तरह याद है! आपने अभी मुझसे ये बातें कही थीं: $summary। बताइए Boss, आगे क्या करना है? 😊"
                    DetectedLanguage.HINGLISH -> "Ji Boss, mujhe hamari conversation memory bilkul yaad hai! Aapne abhi pucha tha: $summary. Bataiye Boss, agla command kya hai? 😊"
                    DetectedLanguage.ENGLISH -> "Of course, Boss! I remember our conversation context clearly. Your recent messages were: $summary. How would you like to proceed, Boss? 😊"
                }
            } else {
                when (detectedLanguage) {
                    DetectedLanguage.HINDI -> "Boss, यह हमारी नई बातचीत की शुरुआत है। आप जो भी बताएँगे, मैं इस सेशन में याद रखूँगी! 👑"
                    DetectedLanguage.HINGLISH -> "Boss, yeh hamari conversation ki shuruat hai. Aap jo bhi bolenge, main poora context yaad rakhungi! 👑"
                    DetectedLanguage.ENGLISH -> "Boss, we just started this conversation! I am tracking our full context from here on. 👑"
                }
            }
        }

        if (lower.contains("kya kar rahi ho") || lower.contains("क्या कर रही हो") || lower.contains("what are you doing")) {
            return when (detectedLanguage) {
                DetectedLanguage.HINDI -> "Boss, मैं आपके अगले command का इंतज़ार कर रही हूँ। 😊 बताइए, आज हम किस मिशन पर काम करें?"
                DetectedLanguage.HINGLISH -> "Boss, main aapke agle command ka intezaar kar rahi hoon. 😊 Bataiye Boss, aaj kis mission par focus karein?"
                DetectedLanguage.ENGLISH -> "Boss, I am waiting for your next command and keeping your workspace ready! 😊 What mission shall we tackle now?"
            }
        }

        if (lower.contains("naam kya hai") || lower.contains("नाम क्या है") || lower.contains("who are you") || lower.contains("tum kaun ho") || lower.contains("your name")) {
            return when (detectedLanguage) {
                DetectedLanguage.HINDI -> "Boss, मेरा नाम RANI है — आपकी personal AI assistant। 👑 मैं आपकी योजना, रिमाइंडर्स, नोट्स, लाइव मौसम और सवालों में मदद करने के लिए हमेशा तैयार हूँ।"
                DetectedLanguage.HINGLISH -> "Boss, mera naam RANI hai — aapki personal AI assistant. 👑 Main aapke plans, reminders, notes, live weather aur har sawal mein madad ke liye hamesha ready hoon!"
                DetectedLanguage.ENGLISH -> "Boss, my name is RANI — your personal AI assistant. 👑 I'm intelligent, calm, and always ready to help you with your daily plan, reminders, notes, weather, and questions."
            }
        }

        if (lower.contains("kaise ho") || lower.contains("kaisi ho") || lower.contains("कैसी हो") || lower.contains("how are you")) {
            return when (detectedLanguage) {
                DetectedLanguage.HINDI -> "Boss, मेरे सभी न्यूरल सिस्टम्स 100% एक्टिव हैं और मैं बिल्कुल शानदार हूँ! 😊 आपका दिन कैसा चल रहा है, Boss?"
                DetectedLanguage.HINGLISH -> "Boss, main bilkul badhiya aur 100% active hoon! 😊 Aap bataiye Boss, aaj ka din kaisa chal raha hai?"
                DetectedLanguage.ENGLISH -> "Boss, all my neural systems are running at 100% and I'm doing great! 😊 How is your day going, Boss?"
            }
        }

        if (lower.contains("weather") || lower.contains("mausam") || lower.contains("मौसम") || lower.contains("barish") || lower.contains("temperature")) {
            return if (weather != null) {
                when (detectedLanguage) {
                    DetectedLanguage.HINDI -> "Boss, अभी ${weather.cityName} में तापमान ${weather.temperatureC}°C है (${weather.conditionHindi} ${weather.emoji})। आज का अधिकतम तापमान ${weather.highC}°C, न्यूनतम ${weather.lowC}°C और बारिश की संभावना ${weather.rainProbability}% है।"
                    DetectedLanguage.HINGLISH -> "Boss, abhi ${weather.cityName} ka temperature ${weather.temperatureC}°C hai (${weather.conditionEnglish} ${weather.emoji}). Aaj high ${weather.highC}°C, low ${weather.lowC}°C aur rain chance ${weather.rainProbability}% hai."
                    DetectedLanguage.ENGLISH -> "Boss, the live weather in ${weather.cityName} is currently ${weather.temperatureC}°C (${weather.conditionEnglish} ${weather.emoji}). Today's high is ${weather.highC}°C, low is ${weather.lowC}°C, wind speed is ${weather.windKmh} km/h, and rain probability is ${weather.rainProbability}%."
                }
            } else {
                when (detectedLanguage) {
                    DetectedLanguage.HINDI -> "Boss, आप नीचे 'Weather' Quick Action बटन दबाकर अपने शहर का लाइव मौसम और तापमान तुरंत देख सकते हैं!"
                    DetectedLanguage.HINGLISH -> "Boss, aap neeche 'Weather' Quick Action button tap karke apne city ka live temperature aur forecast dekh sakte hain!"
                    DetectedLanguage.ENGLISH -> "Boss, tap the 'Weather' Quick Action button below to fetch live satellite weather telemetry for your city!"
                }
            }
        }

        if (lower.contains("plan") || lower.contains("schedule") || lower.contains("प्लान") || lower.contains("दिनचर्या") || lower.contains("focus") || lower.contains("productivity")) {
            val pending = plans.filter { !it.isDone }
            return if (pending.isEmpty()) {
                when (detectedLanguage) {
                    DetectedLanguage.HINDI -> "Boss, आपके 'आज का Plan' के सभी कार्य पूरे हो चुके हैं! 🎉 क्या आप कोई नया मिशन जोड़ना चाहेंगे?"
                    DetectedLanguage.HINGLISH -> "Boss, aapke 'Aaj ka Plan' ke saare tasks complete ho chuke hain! 🎉 Kya main koi naya task add karoon?"
                    DetectedLanguage.ENGLISH -> "Boss, all tasks in your Today's Plan are completed! 🎉 Would you like to add a new high-priority mission?"
                }
            } else {
                val listStr = pending.joinToString("\n") { "• ${it.title} (${it.timeSlot}) [${it.priority}]" }
                when (detectedLanguage) {
                    DetectedLanguage.HINDI -> "Boss, आपके आज के प्लान में ${pending.size} मुख्य कार्य बाकी हैं:\n$listStr\n\nमेरी सलाह है कि सबसे पहले HIGH प्रायोरिटी वाले काम से शुरुआत करें!"
                    DetectedLanguage.HINGLISH -> "Boss, aapke Aaj ke Plan mein ${pending.size} tasks pending hain:\n$listStr\n\nMera suggestion hai ki aap sabse pehle HIGH priority task par focus karein, Boss! 🚀"
                    DetectedLanguage.ENGLISH -> "Boss, you have ${pending.size} pending tasks in Today's Plan:\n$listStr\n\nI recommend tackling your top HIGH priority block first with zero distractions! 🚀"
                }
            }
        }

        if (lower.contains("reminder") || lower.contains("रिमाइंडर") || lower.contains("yaad")) {
            val active = reminders.filter { !it.isCompleted }
            return if (active.isEmpty()) {
                when (detectedLanguage) {
                    DetectedLanguage.HINDI -> "Boss, अभी आपका कोई पेंडिंग रिमाइंडर नहीं है। नया रिमाइंडर जोड़ने के लिए बस मुझे समय बताइए या 'Reminder' बटन दबाइए।"
                    DetectedLanguage.HINGLISH -> "Boss, abhi aapka koi pending reminder nahi hai. Naya reminder set karne ke liye mujhe time bataiye ya 'Reminder' button tap karein."
                    DetectedLanguage.ENGLISH -> "Boss, you have no pending reminders right now. Tell me a time or tap the 'Reminder' button to add one!"
                }
            } else {
                val listStr = active.joinToString("\n") { "• ${it.title} — ⏰ ${it.timeText}" }
                when (detectedLanguage) {
                    DetectedLanguage.HINDI -> "Boss, आपके एक्टिव इन-ऐप रिमाइंडर्स ये हैं:\n$listStr"
                    DetectedLanguage.HINGLISH -> "Boss, aapke active in-app reminders yeh hain:\n$listStr"
                    DetectedLanguage.ENGLISH -> "Boss, here are your active in-app reminders:\n$listStr"
                }
            }
        }

        if (lower.contains("note") || lower.contains("नोट")) {
            return if (notes.isEmpty()) {
                when (detectedLanguage) {
                    DetectedLanguage.HINDI -> "Boss, अभी आपके Notes सेक्शन में कोई नोट नहीं है। आप 'Notes' बटन पर टैप करके तुरंत नोट बना सकते हैं।"
                    DetectedLanguage.HINGLISH -> "Boss, abhi aapke Notes vault mein koi note nahi hai. Aap 'Notes' button se naya note save kar sakte hain."
                    DetectedLanguage.ENGLISH -> "Boss, your Notes vault is currently empty. Tap the 'Notes' button to save key thoughts or meeting points!"
                }
            } else {
                val listStr = notes.take(3).joinToString("\n") { "• ${it.title}: ${it.content.take(70)}" }
                when (detectedLanguage) {
                    DetectedLanguage.HINDI -> "Boss, आपके सेव किए गए प्रमुख नोट्स और मुख्य बिंदु:\n$listStr"
                    DetectedLanguage.HINGLISH -> "Boss, aapke saved notes ka quick summary:\n$listStr"
                    DetectedLanguage.ENGLISH -> "Boss, here is a summary of your saved notes:\n$listStr"
                }
            }
        }

        val pendingRemCount = reminders.count { !it.isCompleted }
        val pendingPlanCount = plans.count { !it.isDone }
        return when (detectedLanguage) {
            DetectedLanguage.HINDI -> "जी Boss! मैंने आपका संदेश (\"$input\") समझ लिया है। अभी आपके $pendingPlanCount प्लान टास्क और $pendingRemCount रिमाइंडर एक्टिव हैं। गहरे क्लाउड AI विश्लेषण के लिए कृपया AI Studio के Secrets पैनल में अपना `GEMINI_API_KEY` जोड़ें। बताइए Boss, मैं अभी आपकी क्या मदद करूँ? 👑"
            DetectedLanguage.HINGLISH -> "Ji Boss! Maine aapki baat (\"$input\") note kar li hai. Abhi aapke $pendingPlanCount plan tasks aur $pendingRemCount reminders active hain. Deep Gemini AI cloud responses ke liye AI Studio ke Secrets panel mein `GEMINI_API_KEY` configure karein. Bataiye Boss, agla command kya hai? 😊👑"
            DetectedLanguage.ENGLISH -> "Got it, Boss! I've noted your query (\"$input\"). You currently have $pendingPlanCount active tasks in Today's Plan and $pendingRemCount reminders. For full cloud generative reasoning, configure `GEMINI_API_KEY` in the AI Studio Secrets panel. How else can I assist you right now, Boss? 👑"
        }
    }
}
