package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ChatMessageEntity::class,
        ReminderEntity::class,
        PlanTaskEntity::class,
        NoteEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class RaniDatabase : RoomDatabase() {
    abstract fun raniDao(): RaniDao

    companion object {
        @Volatile
        private var INSTANCE: RaniDatabase? = null

        fun getInstance(context: Context): RaniDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    RaniDatabase::class.java,
                    "rani_assistant_db"
                )
                    .fallbackToDestructiveMigration(true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
