package com.example.util

import java.util.Locale

enum class DetectedLanguage(
    val displayLabel: String,
    val systemPromptDirective: String
) {
    HINDI(
        displayLabel = "Hindi (हिंदी)",
        systemPromptDirective = "Boss spoke in Hindi (Devanagari). Respond naturally in respectful Hindi (Devanagari script) and address the user as 'Boss'."
    ),
    HINGLISH(
        displayLabel = "Hinglish",
        systemPromptDirective = "Boss spoke in Hinglish (Conversational Hindi in Roman/Latin script mixed with English). Respond naturally in Hinglish and address the user as 'Boss'."
    ),
    ENGLISH(
        displayLabel = "English",
        systemPromptDirective = "Boss spoke in English. Respond naturally in clear, helpful English and address the user as 'Boss'."
    )
}

object LanguageDetector {

    private val hinglishWords = setOf(
        "kya", "kaise", "kaisa", "kaisi", "kab", "kahan", "kyun", "kyu", "kaun",
        "mera", "meri", "mere", "mujhe", "mujhko", "tum", "tumhara", "tumhari", "aap", "aapka",
        "hai", "hain", "ho", "tha", "thi", "the", "raha", "rahi", "rahe", "kar", "karo", "karna",
        "batao", "bata", "suno", "sunao", "dikhao", "likho", "yaad", "dilana", "dila", "kal", "aaj",
        "abhi", "shaam", "subah", "raat", "baje", "mein", "par", "se", "ko", "ka", "ki", "ke",
        "aur", "ya", "lekin", "agar", "toh", "nahi", "nhi", "haan", "achha", "acha", "theek",
        "mausam", "baat", "kaam", "waqt", "samay", "madad", "chahiye", "sakti", "sakta", "wala"
    )

    fun detect(text: String, preferredLanguageHint: String = "Auto"): DetectedLanguage {
        when (preferredLanguageHint.trim().lowercase(Locale.ROOT)) {
            "hindi" -> return DetectedLanguage.HINDI
            "hinglish" -> return DetectedLanguage.HINGLISH
            "english" -> return DetectedLanguage.ENGLISH
        }

        val cleaned = text.trim()
        if (cleaned.isEmpty()) return DetectedLanguage.HINGLISH

        // 1. Check for Devanagari characters (Unicode range \u0900-\u097F)
        val hasDevanagari = cleaned.any { it in '\u0900'..'\u097F' }
        if (hasDevanagari) {
            return DetectedLanguage.HINDI
        }

        // 2. Tokenize words and check for common Hinglish vocabulary
        val tokens = cleaned
            .lowercase(Locale.ROOT)
            .split(Regex("""[^a-z0-9']+"""))
            .filter { it.isNotBlank() }

        if (tokens.isEmpty()) return DetectedLanguage.HINGLISH

        val hinglishMatches = tokens.count { it in hinglishWords }
        if (hinglishMatches >= 1) {
            return DetectedLanguage.HINGLISH
        }

        return DetectedLanguage.ENGLISH
    }
}
