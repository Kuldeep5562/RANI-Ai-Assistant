package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Deep Cosmic Obsidian Backgrounds
val RaniSpaceBlack = Color(0xFF06030D)
val RaniDeepBackground = Color(0xFF0A0517)
val RaniSurfaceDark = Color(0xFF130B29)
val RaniSurfaceElevated = Color(0xFF1C113A)
val RaniSurfaceGlass = Color(0xCC190E34)

// Royal Purple & Electric Blue/Cyan Glow Accents
val RaniRoyalPurple = Color(0xFFA855F7)
val RaniVibrantViolet = Color(0xFFC084FC)
val RaniDeepViolet = Color(0xFF6B21A8)
val RaniElectricBlue = Color(0xFF3B82F6)
val RaniCyberCyan = Color(0xFF00E5FF)
val RaniNeonPink = Color(0xFFF43F5E)
val RaniGoldCrown = Color(0xFFFBBF24)
val RaniEmeraldSuccess = Color(0xFF10B981)

// Text & Border Colors
val RaniTextPrimary = Color(0xFFF5F3FF)
val RaniTextSecondary = Color(0xFFC4B5FD)
val RaniTextMuted = Color(0xFF8B7AA8)
val RaniBorderGlow = Color(0x66A855F7)
val RaniCyanBorderGlow = Color(0x6600E5FF)
