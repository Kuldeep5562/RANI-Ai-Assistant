package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val RaniDarkColorScheme = darkColorScheme(
    primary = RaniRoyalPurple,
    onPrimary = Color.White,
    primaryContainer = RaniDeepViolet,
    onPrimaryContainer = RaniTextPrimary,
    secondary = RaniCyberCyan,
    onSecondary = RaniSpaceBlack,
    secondaryContainer = Color(0xFF0F2942),
    onSecondaryContainer = RaniCyberCyan,
    tertiary = RaniElectricBlue,
    onTertiary = Color.White,
    background = RaniDeepBackground,
    onBackground = RaniTextPrimary,
    surface = RaniSurfaceDark,
    onSurface = RaniTextPrimary,
    surfaceVariant = RaniSurfaceElevated,
    onSurfaceVariant = RaniTextSecondary,
    outline = RaniBorderGlow,
    error = RaniNeonPink,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = RaniDarkColorScheme,
        typography = Typography,
        content = content
    )
}
