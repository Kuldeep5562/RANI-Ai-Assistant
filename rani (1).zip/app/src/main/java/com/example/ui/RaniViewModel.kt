package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AssistantErrorType
import com.example.data.RaniRepository
import com.example.data.local.ChatMessageEntity
import com.example.data.local.NoteEntity
import com.example.data.local.PlanTaskEntity
import com.example.data.local.RaniDatabase
import com.example.data.local.ReminderEntity
import com.example.data.remote.WeatherSnapshot
import com.example.util.DetectedLanguage
import com.example.voice.RaniVoiceManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

enum class QuickActionSheet {
    NONE,
    ASK_RANI,
    REMINDERS,
    TODAY_PLAN,
    WEATHER,
    NOTES,
    SEARCH,
    SETTINGS
}

enum class RaniOrbState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING
}

data class PresetCity(
    val name: String,
    val region: String,
    val lat: Double,
    val lon: Double
)

data class ErrorRetryState(
    val message: String,
    val lastUserPrompt: String?,
    val canRetry: Boolean,
    val errorType: AssistantErrorType?
)

class RaniViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("rani_boss_prefs", Context.MODE_PRIVATE)
    private val database = RaniDatabase.getInstance(application)
    private val repository = RaniRepository(database.raniDao())

    val messages: StateFlow<List<ChatMessageEntity>> = repository.messagesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val reminders: StateFlow<List<ReminderEntity>> = repository.remindersFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val planTasks: StateFlow<List<PlanTaskEntity>> = repository.planTasksFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notes: StateFlow<List<NoteEntity>> = repository.notesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _isThinking = MutableStateFlow(false)
    val isThinking: StateFlow<Boolean> = _isThinking.asStateFlow()

    private val _activeSheet = MutableStateFlow(QuickActionSheet.NONE)
    val activeSheet: StateFlow<QuickActionSheet> = _activeSheet.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private val _errorRetryState = MutableStateFlow<ErrorRetryState?>(null)
    val errorRetryState: StateFlow<ErrorRetryState?> = _errorRetryState.asStateFlow()

    private val _lastDetectedLanguage = MutableStateFlow(DetectedLanguage.HINGLISH)
    val lastDetectedLanguage: StateFlow<DetectedLanguage> = _lastDetectedLanguage.asStateFlow()

    private val _voiceEnabled = MutableStateFlow(prefs.getBoolean("voice_enabled", true))
    val voiceEnabled: StateFlow<Boolean> = _voiceEnabled.asStateFlow()

    private val _autoSpeakReplies = MutableStateFlow(prefs.getBoolean("auto_speak", true))
    val autoSpeakReplies: StateFlow<Boolean> = _autoSpeakReplies.asStateFlow()

    private val _languagePreference = MutableStateFlow(prefs.getString("lang_pref", "Auto") ?: "Auto")
    val languagePreference: StateFlow<String> = _languagePreference.asStateFlow()

    private val _highGlowIntensity = MutableStateFlow(prefs.getBoolean("high_glow", true))
    val highGlowIntensity: StateFlow<Boolean> = _highGlowIntensity.asStateFlow()

    private val _speechRate = MutableStateFlow(prefs.getFloat("speech_rate", 1.0f))
    val speechRate: StateFlow<Float> = _speechRate.asStateFlow()

    val presetCities = listOf(
        PresetCity("New Delhi", "Delhi, India", 28.6139, 77.2090),
        PresetCity("Mumbai", "Maharashtra, India", 19.0760, 72.8777),
        PresetCity("Bengaluru", "Karnataka, India", 12.9716, 77.5946),
        PresetCity("Jaipur", "Rajasthan, India", 26.9124, 75.7873),
        PresetCity("Lucknow", "Uttar Pradesh, India", 26.8467, 80.9462)
    )

    private val _weatherSnapshot = MutableStateFlow<WeatherSnapshot?>(null)
    val weatherSnapshot: StateFlow<WeatherSnapshot?> = _weatherSnapshot.asStateFlow()

    private val _isWeatherLoading = MutableStateFlow(false)
    val isWeatherLoading: StateFlow<Boolean> = _isWeatherLoading.asStateFlow()

    private val _weatherError = MutableStateFlow<String?>(null)
    val weatherError: StateFlow<String?> = _weatherError.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val voiceManager = RaniVoiceManager(
        context = application.applicationContext,
        onSpeechResult = { spokenText ->
            _inputText.value = spokenText
            sendMessage(spokenText)
        },
        onVoiceNotice = { notice ->
            _statusBanner.value = notice
        }
    ).apply {
        voiceMasterEnabled = _voiceEnabled.value
        speechRate = _speechRate.value
    }

    init {
        viewModelScope.launch {
            repository.ensureSeedData()
        }
        loadPresetCityWeather(presetCities.first())
    }

    fun getDynamicGreeting(): String {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when (hour) {
            in 4..11 -> "Good Morning, Boss"
            in 12..16 -> "Good Afternoon, Boss"
            else -> "Good Evening, Boss"
        }
    }

    fun getDynamicHindiSubGreeting(): String {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when (hour) {
            in 4..11 -> "RANI आपके आज के मिशन और कमांड्स के लिए तैयार है 👑"
            in 12..16 -> "Boss, दोपहर का शेड्यूल और न्यूरल असिस्टेंस एक्टिव है ⚡"
            else -> "Boss, मैं आपके अगले command का इंतज़ार कर रही हूँ ✨"
        }
    }

    fun isGeminiKeyConfigured(): Boolean = repository.isApiKeyConfigured()

    fun updateInputText(text: String) {
        _inputText.value = text
    }

    fun dismissBanner() {
        _statusBanner.value = null
    }

    fun dismissErrorRetry() {
        _errorRetryState.value = null
    }

    fun openSheet(sheet: QuickActionSheet) {
        _activeSheet.value = sheet
        if (sheet == QuickActionSheet.WEATHER && _weatherSnapshot.value == null && !_isWeatherLoading.value) {
            loadPresetCityWeather(presetCities.first())
        }
    }

    fun closeSheet() {
        _activeSheet.value = QuickActionSheet.NONE
    }

    fun sendMessage(customText: String? = null, isRetry: Boolean = false) {
        val messageToSend = (customText ?: _inputText.value).trim()
        if (messageToSend.isEmpty() || _isThinking.value) return

        if (customText == null) {
            _inputText.value = ""
        }
        _statusBanner.value = null
        _errorRetryState.value = null
        _isThinking.value = true
        voiceManager.stopSpeaking()

        viewModelScope.launch {
            try {
                val result = repository.sendUserMessageAndGetReply(
                    userText = messageToSend,
                    preferredLanguageHint = _languagePreference.value,
                    currentWeather = _weatherSnapshot.value,
                    isRetryAttempt = isRetry
                )
                _lastDetectedLanguage.value = result.detectedLanguage

                if (result.errorBanner != null) {
                    _errorRetryState.value = ErrorRetryState(
                        message = result.errorBanner,
                        lastUserPrompt = messageToSend,
                        canRetry = result.canRetry,
                        errorType = result.errorType
                    )
                }

                if (_voiceEnabled.value && _autoSpeakReplies.value) {
                    voiceManager.speak(result.raniMessage.message, _languagePreference.value)
                }
            } catch (e: Exception) {
                _errorRetryState.value = ErrorRetryState(
                    message = "Boss, कनेक्शन में त्रुटि आई (${e.localizedMessage ?: "Network Error"})। कृपया Retry दबाएँ।",
                    lastUserPrompt = messageToSend,
                    canRetry = true,
                    errorType = AssistantErrorType.NetworkFailure(e.localizedMessage ?: "Error")
                )
            } finally {
                _isThinking.value = false
            }
        }
    }

    fun retryLastMessage() {
        val promptToRetry = _errorRetryState.value?.lastUserPrompt
            ?: messages.value.lastOrNull { it.sender == "USER" }?.message
        if (!promptToRetry.isNullOrBlank()) {
            sendMessage(customText = promptToRetry, isRetry = true)
        } else {
            _errorRetryState.value = null
        }
    }

    fun speakMessage(text: String) {
        if (!_voiceEnabled.value) {
            setVoiceEnabled(true)
        }
        voiceManager.speak(text, _languagePreference.value)
    }

    fun stopSpeaking() {
        voiceManager.stopSpeaking()
    }

    fun setVoiceEnabled(enabled: Boolean) {
        _voiceEnabled.value = enabled
        voiceManager.voiceMasterEnabled = enabled
        prefs.edit().putBoolean("voice_enabled", enabled).apply()
        if (!enabled) {
            voiceManager.stopSpeaking()
            voiceManager.stopListening()
        }
    }

    fun toggleAutoSpeak() {
        val next = !_autoSpeakReplies.value
        _autoSpeakReplies.value = next
        prefs.edit().putBoolean("auto_speak", next).apply()
        if (!next) {
            voiceManager.stopSpeaking()
        } else if (!_voiceEnabled.value) {
            setVoiceEnabled(true)
        }
    }

    fun setLanguagePreference(lang: String) {
        _languagePreference.value = lang
        prefs.edit().putString("lang_pref", lang).apply()
    }

    fun setHighGlowIntensity(enabled: Boolean) {
        _highGlowIntensity.value = enabled
        prefs.edit().putBoolean("high_glow", enabled).apply()
    }

    fun setSpeechRateValue(rate: Float) {
        _speechRate.value = rate
        voiceManager.speechRate = rate
        prefs.edit().putFloat("speech_rate", rate).apply()
    }

    fun startVoiceListening() {
        _statusBanner.value = null
        if (!_voiceEnabled.value) {
            setVoiceEnabled(true)
        }
        voiceManager.startListening(_languagePreference.value)
    }

    fun stopVoiceListening() {
        voiceManager.stopListening()
    }

    fun addReminder(title: String, timeText: String) {
        if (title.isBlank()) return
        viewModelScope.launch {
            repository.addReminder(title, timeText.ifBlank { "आज शाम 7:00 बजे" })
            _statusBanner.value = "Boss, नया रिमाइंडर सेव कर दिया गया है!"
        }
    }

    fun toggleReminder(reminder: ReminderEntity) {
        viewModelScope.launch { repository.toggleReminder(reminder) }
    }

    fun deleteReminder(id: Long) {
        viewModelScope.launch { repository.deleteReminder(id) }
    }

    fun addPlanTask(title: String, timeSlot: String, priority: String) {
        if (title.isBlank()) return
        viewModelScope.launch {
            repository.addPlanTask(title, timeSlot.ifBlank { "Flexible Slot" }, priority)
            _statusBanner.value = "Boss, आज के Plan में नया कार्य जोड़ दिया गया है!"
        }
    }

    fun togglePlanTask(task: PlanTaskEntity) {
        viewModelScope.launch { repository.togglePlanTask(task) }
    }

    fun deletePlanTask(id: Long) {
        viewModelScope.launch { repository.deletePlanTask(id) }
    }

    fun addNote(title: String, content: String, category: String) {
        if (title.isBlank() && content.isBlank()) return
        viewModelScope.launch {
            repository.addNote(title.ifBlank { content.take(24) }, content.ifBlank { title }, category)
            _statusBanner.value = "Boss, आपका नोट सुरक्षित सेव हो गया है!"
        }
    }

    fun deleteNote(id: Long) {
        viewModelScope.launch { repository.deleteNote(id) }
    }

    fun loadPresetCityWeather(city: PresetCity) {
        _isWeatherLoading.value = true
        _weatherError.value = null
        viewModelScope.launch {
            val result = repository.fetchLiveWeather(city.name, city.lat, city.lon, city.region)
            result.onSuccess { _weatherSnapshot.value = it }
                .onFailure { _weatherError.value = "Boss, अभी लाइव मौसम डेटा लोड नहीं हो सका। कृपया इंटरनेट चेक करें।" }
            _isWeatherLoading.value = false
        }
    }

    fun searchCityWeather(cityName: String) {
        if (cityName.isBlank()) return
        _isWeatherLoading.value = true
        _weatherError.value = null
        viewModelScope.launch {
            val result = repository.searchAndFetchCityWeather(cityName)
            result.onSuccess { _weatherSnapshot.value = it }
                .onFailure { _weatherError.value = "Boss, \"$cityName\" शहर का मौसम डेटा नहीं मिला।" }
            _isWeatherLoading.value = false
        }
    }

    fun updateSearchQuery(q: String) {
        _searchQuery.value = q
    }

    fun resetToSampleConversation() {
        viewModelScope.launch {
            repository.resetSampleConversation()
            _errorRetryState.value = null
            _statusBanner.value = "Boss, सैंपल बातचीत फिर से रीसेट कर दी गई है!"
        }
    }

    fun clearChatHistory() {
        viewModelScope.launch {
            repository.clearChatHistory()
            _errorRetryState.value = null
            _statusBanner.value = "Boss, Conversation Memory साफ़ कर दी गई है।"
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.release()
    }
}
