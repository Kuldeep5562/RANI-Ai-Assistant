package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.ChatMessageEntity
import com.example.data.local.NoteEntity
import com.example.data.local.PlanTaskEntity
import com.example.data.local.ReminderEntity
import com.example.ui.theme.RaniBorderGlow
import com.example.ui.theme.RaniCyberCyan
import com.example.ui.theme.RaniEmeraldSuccess
import com.example.ui.theme.RaniGoldCrown
import com.example.ui.theme.RaniNeonPink
import com.example.ui.theme.RaniRoyalPurple
import com.example.ui.theme.RaniSurfaceElevated
import com.example.ui.theme.RaniTextMuted
import com.example.ui.theme.RaniTextPrimary
import com.example.ui.theme.RaniTextSecondary
import com.example.ui.theme.RaniVibrantViolet

data class UnifiedSearchHit(
    val badge: String,
    val title: String,
    val snippet: String
)

@Composable
fun SearchSheetContent(
    query: String,
    onQueryChange: (String) -> Unit,
    messages: List<ChatMessageEntity>,
    reminders: List<ReminderEntity>,
    tasks: List<PlanTaskEntity>,
    notes: List<NoteEntity>,
    onAskRaniSearch: (String) -> Unit,
    onClose: () -> Unit
) {
    val hits = remember(query, messages, reminders, tasks, notes) {
        val q = query.trim().lowercase()
        val list = mutableListOf<UnifiedSearchHit>()
        if (q.isEmpty()) {
            reminders.take(2).forEach {
                list.add(UnifiedSearchHit("REMINDER", it.title, it.timeText))
            }
            tasks.take(2).forEach {
                list.add(UnifiedSearchHit("PLAN", it.title, "${it.timeSlot} • ${it.priority}"))
            }
            notes.take(2).forEach {
                list.add(UnifiedSearchHit("NOTE", it.title, it.content))
            }
        } else {
            messages.filter { it.message.lowercase().contains(q) }.take(6).forEach {
                list.add(UnifiedSearchHit(if (it.sender == "RANI") "RANI CHAT" else "BOSS CHAT", it.sender, it.message))
            }
            reminders.filter { it.title.lowercase().contains(q) || it.timeText.lowercase().contains(q) }.forEach {
                list.add(UnifiedSearchHit("REMINDER", it.title, it.timeText))
            }
            tasks.filter { it.title.lowercase().contains(q) }.forEach {
                list.add(UnifiedSearchHit("PLAN", it.title, it.timeSlot))
            }
            notes.filter { it.title.lowercase().contains(q) || it.content.lowercase().contains(q) }.forEach {
                list.add(UnifiedSearchHit("NOTE", it.title, it.content))
            }
        }
        list
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
    ) {
        SheetHeader(
            title = "RANI Neural Search",
            subtitle = "चैट, रिमाइंडर, नोट्स खोजें या RANI से कोई भी विषय पूछें",
            icon = Icons.Filled.Search,
            accentColor = RaniCyberCyan,
            onClose = onClose
        )

        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            placeholder = { Text("खोजें या कोई भी टॉपिक टाइप करें, Boss…", color = RaniTextMuted) },
            leadingIcon = {
                Icon(Icons.Filled.Search, contentDescription = null, tint = RaniCyberCyan)
            },
            singleLine = true,
            colors = raniTextFieldColors(),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("neural_search_input")
        )

        Spacer(modifier = Modifier.height(10.dp))

        if (query.isNotBlank()) {
            Button(
                onClick = {
                    onAskRaniSearch("Boss चाहता है कि तुम इस विषय पर स्पष्ट जानकारी दो: $query")
                    onClose()
                },
                colors = ButtonDefaults.buttonColors(containerColor = RaniRoyalPurple),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Filled.AutoAwesome, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("RANI AI से \"$query\" के बारे में पूछें")
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 260.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(hits) { hit ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(RaniSurfaceElevated)
                        .border(1.dp, RaniBorderGlow, RoundedCornerShape(14.dp))
                        .clickable {
                            onAskRaniSearch("Rani, '${hit.title}' (${hit.snippet}) के बारे में बताओ।")
                            onClose()
                        }
                        .padding(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = hit.badge,
                            style = MaterialTheme.typography.labelSmall,
                            color = RaniCyberCyan
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = hit.title,
                            style = MaterialTheme.typography.titleSmall,
                            color = RaniTextPrimary
                        )
                    }
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = hit.snippet,
                        style = MaterialTheme.typography.bodySmall,
                        color = RaniTextSecondary,
                        maxLines = 2
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))
    }
}

@Composable
fun SettingsSheetContent(
    voiceEnabled: Boolean,
    onVoiceEnabledChange: (Boolean) -> Unit,
    autoSpeakEnabled: Boolean,
    onToggleAutoSpeak: () -> Unit,
    speechRate: Float,
    onSpeechRateChange: (Float) -> Unit,
    languagePreference: String,
    onLanguageChange: (String) -> Unit,
    highGlowEnabled: Boolean,
    onHighGlowChange: (Boolean) -> Unit,
    isGeminiKeyConfigured: Boolean,
    messageCount: Int,
    onTestVoiceSample: () -> Unit,
    onResetSampleConversation: () -> Unit,
    onClearChatHistory: () -> Unit,
    onClose: () -> Unit
) {
    val languages = listOf("Auto", "Hinglish", "Hindi", "English")

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 8.dp)
    ) {
        SheetHeader(
            title = "RANI Voice & Core Settings",
            subtitle = "Voice On/Off, Speed, Auto Speak, Language & Conversation Memory",
            icon = Icons.Filled.Settings,
            accentColor = RaniVibrantViolet,
            onClose = onClose
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(RaniSurfaceElevated)
                .border(1.dp, RaniBorderGlow, RoundedCornerShape(14.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Voice On / Off (मास्टर वॉइस)",
                    style = MaterialTheme.typography.titleSmall,
                    color = RaniTextPrimary
                )
                Text(
                    text = if (voiceEnabled) "RANI की आवाज़ और वॉइस सिस्टम चालू है" else "RANI की आवाज़ बंद (Silent Text Mode) है",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (voiceEnabled) RaniCyberCyan else RaniTextSecondary
                )
            }
            Switch(
                checked = voiceEnabled,
                onCheckedChange = onVoiceEnabledChange,
                modifier = Modifier.testTag("voice_master_switch"),
                colors = SwitchDefaults.colors(
                    checkedThumbColor = RaniCyberCyan,
                    checkedTrackColor = RaniRoyalPurple.copy(alpha = 0.5f)
                )
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(RaniSurfaceElevated)
                .border(1.dp, RaniBorderGlow, RoundedCornerShape(14.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Auto Speak (ऑटोमैटिक आवाज़ में जवाब)",
                    style = MaterialTheme.typography.titleSmall,
                    color = RaniTextPrimary
                )
                Text(
                    text = "Boss के सवाल का जवाब मिलते ही RANI बोलकर सुनाएगी",
                    style = MaterialTheme.typography.bodySmall,
                    color = RaniTextSecondary
                )
            }
            Switch(
                checked = autoSpeakEnabled && voiceEnabled,
                onCheckedChange = { onToggleAutoSpeak() },
                modifier = Modifier.testTag("auto_speak_switch"),
                colors = SwitchDefaults.colors(
                    checkedThumbColor = RaniCyberCyan,
                    checkedTrackColor = RaniRoyalPurple.copy(alpha = 0.5f)
                )
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(RaniSurfaceElevated)
                .border(1.dp, RaniBorderGlow, RoundedCornerShape(14.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Voice Speed (आवाज़ की गति)",
                    style = MaterialTheme.typography.titleSmall,
                    color = RaniTextPrimary
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${"%.2f".format(speechRate)}x",
                        style = MaterialTheme.typography.labelLarge,
                        color = RaniCyberCyan
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "🔊 Test",
                        style = MaterialTheme.typography.labelSmall,
                        color = RaniGoldCrown,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(RaniRoyalPurple.copy(alpha = 0.25f))
                            .clickable(onClick = onTestVoiceSample)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
            Slider(
                value = speechRate,
                onValueChange = onSpeechRateChange,
                valueRange = 0.75f..1.40f,
                colors = SliderDefaults.colors(
                    thumbColor = RaniCyberCyan,
                    activeTrackColor = RaniRoyalPurple
                ),
                modifier = Modifier.testTag("voice_speed_slider")
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(RaniSurfaceElevated)
                .border(1.dp, RaniBorderGlow, RoundedCornerShape(14.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.RecordVoiceOver,
                    contentDescription = null,
                    tint = RaniCyberCyan,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Language (भाषा: Auto Hindi / Hinglish / English)",
                    style = MaterialTheme.typography.titleSmall,
                    color = RaniTextPrimary
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                languages.forEach { lang ->
                    FilterChip(
                        selected = languagePreference == lang,
                        onClick = { onLanguageChange(lang) },
                        label = { Text(if (lang == "Auto") "Auto Detect" else lang) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = RaniRoyalPurple.copy(alpha = 0.35f),
                            selectedLabelColor = RaniCyberCyan
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(RaniSurfaceElevated)
                .border(1.dp, RaniBorderGlow, RoundedCornerShape(14.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Futuristic Purple/Cyan Orb Aura",
                    style = MaterialTheme.typography.titleSmall,
                    color = RaniTextPrimary
                )
                Text(
                    text = "Listening, Thinking और Speaking एनीमेशन हाइलाइट",
                    style = MaterialTheme.typography.bodySmall,
                    color = RaniTextSecondary
                )
            }
            Switch(
                checked = highGlowEnabled,
                onCheckedChange = onHighGlowChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = RaniVibrantViolet,
                    checkedTrackColor = RaniRoyalPurple.copy(alpha = 0.5f)
                )
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(RaniSurfaceElevated)
                .border(1.dp, RaniCyberCyan.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                .padding(12.dp)
        ) {
            Text(
                text = "Conversation Memory ($messageCount messages in context)",
                style = MaterialTheme.typography.titleSmall,
                color = RaniCyberCyan
            )
            Text(
                text = "RANI वर्तमान बातचीत का संदर्भ (Context) याद रखती है। आप नीचे Clear Conversation से मेमोरी रीसेट कर सकते हैं।",
                style = MaterialTheme.typography.bodySmall,
                color = RaniTextSecondary
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        onClearChatHistory()
                        onClose()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RaniNeonPink.copy(alpha = 0.85f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("clear_conversation_button")
                ) {
                    Icon(Icons.Filled.DeleteSweep, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Clear Conversation")
                }

                OutlinedButton(
                    onClick = {
                        onResetSampleConversation()
                        onClose()
                    },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("reset_sample_chat_button")
                ) {
                    Icon(Icons.Filled.Restore, contentDescription = null, tint = RaniCyberCyan, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Sample Chat", color = RaniCyberCyan)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(RaniSurfaceElevated)
                .border(1.dp, RaniBorderGlow, RoundedCornerShape(14.dp))
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.Security,
                contentDescription = null,
                tint = if (isGeminiKeyConfigured) RaniEmeraldSuccess else RaniGoldCrown,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = if (isGeminiKeyConfigured) "Gemini 3.5 Flash Secret: Securely Loaded" else "Gemini API Secret: Not Configured (Using Smart Engine)",
                    style = MaterialTheme.typography.labelLarge,
                    color = if (isGeminiKeyConfigured) RaniEmeraldSuccess else RaniGoldCrown
                )
                Text(
                    text = "Zero hardcoded API keys in source code. Credentials are injected strictly via AI Studio Secrets (BuildConfig.GEMINI_API_KEY).",
                    style = MaterialTheme.typography.bodySmall,
                    color = RaniTextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))
    }
}
