package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.EventNote
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.data.local.NoteEntity
import com.example.data.local.PlanTaskEntity
import com.example.data.local.ReminderEntity
import com.example.data.remote.WeatherSnapshot
import com.example.ui.PresetCity
import com.example.ui.theme.RaniBorderGlow
import com.example.ui.theme.RaniCyberCyan
import com.example.ui.theme.RaniElectricBlue
import com.example.ui.theme.RaniEmeraldSuccess
import com.example.ui.theme.RaniGoldCrown
import com.example.ui.theme.RaniNeonPink
import com.example.ui.theme.RaniRoyalPurple
import com.example.ui.theme.RaniSurfaceDark
import com.example.ui.theme.RaniSurfaceElevated
import com.example.ui.theme.RaniTextMuted
import com.example.ui.theme.RaniTextPrimary
import com.example.ui.theme.RaniTextSecondary
import com.example.ui.theme.RaniVibrantViolet

@Composable
fun SheetHeader(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color = RaniCyberCyan,
    onClose: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(accentColor.copy(alpha = 0.16f))
                    .border(1.dp, accentColor.copy(alpha = 0.5f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    color = RaniTextPrimary
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = RaniTextSecondary
                )
            }
        }
        IconButton(onClick = onClose, modifier = Modifier.testTag("close_sheet_button")) {
            Icon(
                imageVector = Icons.Filled.Close,
                contentDescription = "Close",
                tint = RaniTextSecondary
            )
        }
    }
}

// 1. "RANI से पूछें" (Ask RANI Smart Command Hub)
@Composable
fun AskRaniSheetContent(
    onSelectPrompt: (String) -> Unit,
    onClose: () -> Unit
) {
    val promptCategories = listOf(
        "Hinglish Commands" to listOf(
            "Rani, kya kar rahi ho?",
            "Rani, tumhara naam kya hai?",
            "Rani, mujhe kal 7 baje yaad dilana.",
            "Rani, aaj mera focus kis kaam par hona chahiye?",
            "Rani, ek quick motivational quote sunao Boss ke liye!"
        ),
        "हिंदी कमांड्स (Hindi)" to listOf(
            "रानी, आज के मेरे प्लान और रिमाइंडर्स का सारांश बताओ।",
            "रानी, दिमागी फोकस और प्रोडक्टिविटी बढ़ाने के 3 स्मार्ट तरीके बताओ।",
            "रानी, आज शाम के लिए एक शांत और ऊर्जावान रूटीन सुझाओ।"
        ),
        "English Executive Prompts" to listOf(
            "Rani, give me an executive briefing of my reminders and tasks today.",
            "Rani, help me draft a crisp 3-point agenda for my next team meeting.",
            "Rani, explain Quantum Computing in 3 simple sentences for Boss."
        )
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
    ) {
        SheetHeader(
            title = "RANI से पूछें (Ask RANI)",
            subtitle = "Boss, किसी भी स्मार्ट कमांड पर टैप करें या अपना सवाल पूछें",
            icon = Icons.Filled.AutoAwesome,
            accentColor = RaniVibrantViolet,
            onClose = onClose
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 420.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            promptCategories.forEach { (category, prompts) ->
                item {
                    Text(
                        text = category,
                        style = MaterialTheme.typography.labelLarge,
                        color = RaniCyberCyan,
                        modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
                    )
                }
                items(prompts) { prompt ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(RaniSurfaceElevated)
                            .border(1.dp, RaniBorderGlow, RoundedCornerShape(14.dp))
                            .clickable {
                                onSelectPrompt(prompt)
                                onClose()
                            }
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AutoAwesome,
                            contentDescription = null,
                            tint = RaniVibrantViolet,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = prompt,
                            style = MaterialTheme.typography.bodyMedium,
                            color = RaniTextPrimary
                        )
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
    }
}

// 2. "Reminder" Hub Sheet
@Composable
fun ReminderSheetContent(
    reminders: List<ReminderEntity>,
    onAddReminder: (String, String) -> Unit,
    onToggleReminder: (ReminderEntity) -> Unit,
    onDeleteReminder: (Long) -> Unit,
    onAskRaniBriefing: () -> Unit,
    onClose: () -> Unit
) {
    var title by remember { mutableStateOf("") }
    var timeText by remember { mutableStateOf("कल सुबह 7:00 बजे") }
    val quickTimes = listOf("कल सुबह 7:00 बजे", "आज शाम 6:00 बजे", "आज रात 9:00 बजे", "1 घंटे बाद")

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
    ) {
        SheetHeader(
            title = "Boss Reminders",
            subtitle = "इन-ऐप रिमाइंडर्स और समय अलर्ट सूची",
            icon = Icons.Filled.NotificationsActive,
            accentColor = RaniGoldCrown,
            onClose = onClose
        )

        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            placeholder = { Text("रिमाइंडर क्या है, Boss? (उदा. जिम / मीटिंग)", color = RaniTextMuted) },
            singleLine = true,
            colors = raniTextFieldColors(),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("reminder_title_input")
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            quickTimes.forEach { presetTime ->
                FilterChip(
                    selected = timeText == presetTime,
                    onClick = { timeText = presetTime },
                    label = { Text(presetTime, style = MaterialTheme.typography.labelSmall) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = RaniRoyalPurple.copy(alpha = 0.3f),
                        selectedLabelColor = RaniCyberCyan
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = timeText,
                onValueChange = { timeText = it },
                placeholder = { Text("समय (जैसे कल 7:00 बजे)", color = RaniTextMuted) },
                singleLine = true,
                colors = raniTextFieldColors(),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f)
            )
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onAddReminder(title, timeText)
                        title = ""
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = RaniRoyalPurple),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .height(54.dp)
                    .testTag("add_reminder_button")
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Add")
                Spacer(modifier = Modifier.width(4.dp))
                Text("जोड़ें")
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 240.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(reminders, key = { it.id }) { item ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(RaniSurfaceElevated)
                        .border(1.dp, RaniBorderGlow, RoundedCornerShape(14.dp))
                        .clickable { onToggleReminder(item) }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (item.isCompleted) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                        contentDescription = "Toggle complete",
                        tint = if (item.isCompleted) RaniEmeraldSuccess else RaniGoldCrown,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.title,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                textDecoration = if (item.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                            ),
                            color = if (item.isCompleted) RaniTextMuted else RaniTextPrimary
                        )
                        Text(
                            text = "⏰ ${item.timeText}",
                            style = MaterialTheme.typography.bodySmall,
                            color = RaniCyberCyan
                        )
                    }
                    IconButton(onClick = { onDeleteReminder(item.id) }) {
                        Icon(
                            imageVector = Icons.Filled.DeleteOutline,
                            contentDescription = "Delete reminder",
                            tint = RaniNeonPink.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = {
                onAskRaniBriefing()
                onClose()
            },
            colors = ButtonDefaults.buttonColors(containerColor = RaniSurfaceElevated),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, RaniCyberCyan.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
        ) {
            Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = RaniCyberCyan)
            Spacer(modifier = Modifier.width(8.dp))
            Text("RANI से मेरे सभी Reminders सुनें", color = RaniTextPrimary)
        }

        Spacer(modifier = Modifier.height(12.dp))
    }
}

// 3. "आज का Plan" (Today's Plan Sheet)
@Composable
fun TodayPlanSheetContent(
    tasks: List<PlanTaskEntity>,
    onAddTask: (String, String, String) -> Unit,
    onToggleTask: (PlanTaskEntity) -> Unit,
    onDeleteTask: (Long) -> Unit,
    onAskRaniOptimize: () -> Unit,
    onClose: () -> Unit
) {
    var taskTitle by remember { mutableStateOf("") }
    var timeSlot by remember { mutableStateOf("11:00 AM - 12:30 PM") }
    var priority by remember { mutableStateOf("HIGH") }

    val completedCount = tasks.count { it.isDone }
    val progress = if (tasks.isEmpty()) 0f else completedCount.toFloat() / tasks.size.toFloat()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
    ) {
        SheetHeader(
            title = "आज का Plan (Boss Mission)",
            subtitle = "$completedCount / ${tasks.size} कार्य पूरे • उच्च-प्रदर्शन दिनचर्या",
            icon = Icons.Filled.Schedule,
            accentColor = RaniCyberCyan,
            onClose = onClose
        )

        LinearProgressIndicator(
            progress = { progress },
            color = RaniCyberCyan,
            trackColor = RaniSurfaceElevated,
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(50))
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = taskTitle,
            onValueChange = { taskTitle = it },
            placeholder = { Text("आज का नया मिशन जोड़ें, Boss…", color = RaniTextMuted) },
            singleLine = true,
            colors = raniTextFieldColors(),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("plan_task_input")
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = timeSlot,
                onValueChange = { timeSlot = it },
                placeholder = { Text("समय स्लॉट", color = RaniTextMuted) },
                singleLine = true,
                colors = raniTextFieldColors(),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f)
            )
            listOf("HIGH", "MEDIUM").forEach { p ->
                FilterChip(
                    selected = priority == p,
                    onClick = { priority = p },
                    label = { Text(p, style = MaterialTheme.typography.labelSmall) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = if (p == "HIGH") RaniNeonPink.copy(alpha = 0.25f) else RaniElectricBlue.copy(alpha = 0.25f),
                        selectedLabelColor = RaniTextPrimary
                    )
                )
            }
            Button(
                onClick = {
                    if (taskTitle.isNotBlank()) {
                        onAddTask(taskTitle, timeSlot, priority)
                        taskTitle = ""
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = RaniRoyalPurple),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.testTag("add_plan_task_button")
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Add Task")
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 230.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(tasks, key = { it.id }) { task ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(RaniSurfaceElevated)
                        .border(1.dp, RaniBorderGlow, RoundedCornerShape(14.dp))
                        .clickable { onToggleTask(task) }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (task.isDone) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                        contentDescription = null,
                        tint = if (task.isDone) RaniEmeraldSuccess else RaniCyberCyan,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = task.title,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                textDecoration = if (task.isDone) TextDecoration.LineThrough else TextDecoration.None
                            ),
                            color = if (task.isDone) RaniTextMuted else RaniTextPrimary
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = task.timeSlot,
                                style = MaterialTheme.typography.bodySmall,
                                color = RaniTextSecondary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = task.priority,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (task.priority == "HIGH") RaniGoldCrown else RaniCyberCyan
                            )
                        }
                    }
                    IconButton(onClick = { onDeleteTask(task.id) }) {
                        Icon(
                            imageVector = Icons.Filled.DeleteOutline,
                            contentDescription = "Delete Task",
                            tint = RaniNeonPink.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = {
                onAskRaniOptimize()
                onClose()
            },
            colors = ButtonDefaults.buttonColors(containerColor = RaniSurfaceElevated),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, RaniVibrantViolet.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
        ) {
            Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = RaniVibrantViolet)
            Spacer(modifier = Modifier.width(8.dp))
            Text("RANI से आज के Plan पर स्मार्ट सलाह लें", color = RaniTextPrimary)
        }

        Spacer(modifier = Modifier.height(12.dp))
    }
}

// 4. "Weather" Live Telemetry Sheet
@Composable
fun WeatherSheetContent(
    weather: WeatherSnapshot?,
    isLoading: Boolean,
    error: String?,
    presetCities: List<PresetCity>,
    onSelectPresetCity: (PresetCity) -> Unit,
    onSearchCity: (String) -> Unit,
    onAskRaniWeatherBriefing: () -> Unit,
    onClose: () -> Unit
) {
    var customCity by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
    ) {
        SheetHeader(
            title = "Live Weather Telemetry",
            subtitle = "Open-Meteo रियल-टाइम मौसम अपडेट",
            icon = Icons.Filled.Cloud,
            accentColor = RaniCyberCyan,
            onClose = onClose
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            presetCities.forEach { city ->
                FilterChip(
                    selected = weather?.cityName?.equals(city.name, ignoreCase = true) == true,
                    onClick = { onSelectPresetCity(city) },
                    label = { Text(city.name) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = RaniElectricBlue.copy(alpha = 0.3f),
                        selectedLabelColor = RaniCyberCyan
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = customCity,
                onValueChange = { customCity = it },
                placeholder = { Text("अन्य शहर खोजें (उदा. Pune, Indore, London)", color = RaniTextMuted) },
                singleLine = true,
                colors = raniTextFieldColors(),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f)
            )
            Button(
                onClick = {
                    if (customCity.isNotBlank()) {
                        onSearchCity(customCity)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = RaniRoyalPurple),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Filled.Refresh, contentDescription = "Fetch Weather")
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = RaniCyberCyan)
            }
        } else if (error != null && weather == null) {
            Text(text = error, color = RaniNeonPink, style = MaterialTheme.typography.bodyMedium)
        } else if (weather != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(RaniSurfaceElevated, Color(0xFF14213D))
                        )
                    )
                    .border(1.dp, RaniCyberCyan.copy(alpha = 0.45f), RoundedCornerShape(20.dp))
                    .padding(18.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = weather.cityName,
                                style = MaterialTheme.typography.headlineSmall,
                                color = RaniTextPrimary
                            )
                            Text(
                                text = weather.region,
                                style = MaterialTheme.typography.bodySmall,
                                color = RaniTextSecondary
                            )
                        }
                        Text(
                            text = "${weather.emoji} ${weather.temperatureC}°C",
                            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                            color = RaniCyberCyan
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "${weather.conditionHindi} • ${weather.conditionEnglish}",
                        style = MaterialTheme.typography.titleMedium,
                        color = RaniGoldCrown
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "High: ${weather.highC}°C / Low: ${weather.lowC}°C",
                            style = MaterialTheme.typography.bodySmall,
                            color = RaniTextPrimary
                        )
                        Text(
                            text = "Wind: ${weather.windKmh} km/h • Rain: ${weather.rainProbability}%",
                            style = MaterialTheme.typography.bodySmall,
                            color = RaniTextSecondary
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Button(
            onClick = {
                onAskRaniWeatherBriefing()
                onClose()
            },
            colors = ButtonDefaults.buttonColors(containerColor = RaniRoyalPurple),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Filled.AutoAwesome, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("RANI से आज के मौसम की ब्रीफिंग सुनें")
        }

        Spacer(modifier = Modifier.height(12.dp))
    }
}

// 5. "Notes" Neural Vault Sheet
@Composable
fun NotesSheetContent(
    notes: List<NoteEntity>,
    onAddNote: (String, String, String) -> Unit,
    onDeleteNote: (Long) -> Unit,
    onAskRaniSummarizeNote: (NoteEntity) -> Unit,
    onClose: () -> Unit
) {
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
    ) {
        SheetHeader(
            title = "Boss Neural Notes",
            subtitle = "महत्वपूर्ण विचार, मीटिंग पॉइंट्स और मेमोरी वॉल्ट",
            icon = Icons.Filled.EventNote,
            accentColor = RaniVibrantViolet,
            onClose = onClose
        )

        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            placeholder = { Text("नोट का शीर्षक (Title)", color = RaniTextMuted) },
            singleLine = true,
            colors = raniTextFieldColors(),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = content,
                onValueChange = { content = it },
                placeholder = { Text("यहाँ अपना नोट लिखें, Boss…", color = RaniTextMuted) },
                maxLines = 3,
                colors = raniTextFieldColors(),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("note_content_input")
            )
            Button(
                onClick = {
                    if (title.isNotBlank() || content.isNotBlank()) {
                        onAddNote(title, content, "Personal")
                        title = ""
                        content = ""
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = RaniRoyalPurple),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .height(54.dp)
                    .testTag("save_note_button")
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Save Note")
                Spacer(modifier = Modifier.width(4.dp))
                Text("सेव")
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 260.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(notes, key = { it.id }) { note ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(RaniSurfaceElevated)
                        .border(1.dp, RaniBorderGlow, RoundedCornerShape(14.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = note.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = RaniCyberCyan,
                            modifier = Modifier.weight(1f)
                        )
                        Row {
                            IconButton(
                                onClick = {
                                    onAskRaniSummarizeNote(note)
                                    onClose()
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.AutoAwesome,
                                    contentDescription = "Ask RANI about note",
                                    tint = RaniVibrantViolet,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            IconButton(
                                onClick = { onDeleteNote(note.id) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.DeleteOutline,
                                    contentDescription = "Delete Note",
                                    tint = RaniNeonPink.copy(alpha = 0.8f),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = note.content,
                        style = MaterialTheme.typography.bodyMedium,
                        color = RaniTextPrimary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
    }
}

@Composable
fun raniTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedContainerColor = RaniSurfaceDark,
    unfocusedContainerColor = RaniSurfaceDark,
    focusedBorderColor = RaniCyberCyan,
    unfocusedBorderColor = RaniBorderGlow,
    focusedTextColor = RaniTextPrimary,
    unfocusedTextColor = RaniTextPrimary,
    cursorColor = RaniCyberCyan
)
