package com.example.ui.screens

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.EventNote
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.local.ChatMessageEntity
import com.example.ui.ErrorRetryState
import com.example.ui.QuickActionSheet
import com.example.ui.RaniViewModel
import com.example.ui.components.AskRaniSheetContent
import com.example.ui.components.NotesSheetContent
import com.example.ui.components.RaniAiOrbSection
import com.example.ui.components.ReminderSheetContent
import com.example.ui.components.SearchSheetContent
import com.example.ui.components.SettingsSheetContent
import com.example.ui.components.TodayPlanSheetContent
import com.example.ui.components.WeatherSheetContent
import com.example.ui.theme.RaniBorderGlow
import com.example.ui.theme.RaniCyberCyan
import com.example.ui.theme.RaniDeepBackground
import com.example.ui.theme.RaniDeepViolet
import com.example.ui.theme.RaniElectricBlue
import com.example.ui.theme.RaniGoldCrown
import com.example.ui.theme.RaniNeonPink
import com.example.ui.theme.RaniRoyalPurple
import com.example.ui.theme.RaniSpaceBlack
import com.example.ui.theme.RaniSurfaceDark
import com.example.ui.theme.RaniSurfaceElevated
import com.example.ui.theme.RaniTextMuted
import com.example.ui.theme.RaniTextPrimary
import com.example.ui.theme.RaniTextSecondary
import com.example.ui.theme.RaniVibrantViolet
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class QuickActionItem(
    val label: String,
    val icon: ImageVector,
    val sheet: QuickActionSheet,
    val accent: Color,
    val badge: String? = null,
    val testTag: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RaniHomeScreen(
    viewModel: RaniViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current

    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val reminders by viewModel.reminders.collectAsStateWithLifecycle()
    val planTasks by viewModel.planTasks.collectAsStateWithLifecycle()
    val notes by viewModel.notes.collectAsStateWithLifecycle()
    val inputText by viewModel.inputText.collectAsStateWithLifecycle()
    val isThinking by viewModel.isThinking.collectAsStateWithLifecycle()
    val activeSheet by viewModel.activeSheet.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()
    val errorRetryState by viewModel.errorRetryState.collectAsStateWithLifecycle()

    val voiceEnabled by viewModel.voiceEnabled.collectAsStateWithLifecycle()
    val autoSpeak by viewModel.autoSpeakReplies.collectAsStateWithLifecycle()
    val languagePref by viewModel.languagePreference.collectAsStateWithLifecycle()
    val highGlow by viewModel.highGlowIntensity.collectAsStateWithLifecycle()
    val speechRate by viewModel.speechRate.collectAsStateWithLifecycle()

    val weatherSnapshot by viewModel.weatherSnapshot.collectAsStateWithLifecycle()
    val isWeatherLoading by viewModel.isWeatherLoading.collectAsStateWithLifecycle()
    val weatherError by viewModel.weatherError.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()

    val isListening by viewModel.voiceManager.isListening.collectAsStateWithLifecycle()
    val isSpeaking by viewModel.voiceManager.isSpeaking.collectAsStateWithLifecycle()
    val voiceRms by viewModel.voiceManager.voiceRmsLevel.collectAsStateWithLifecycle()
    val partialTranscript by viewModel.voiceManager.partialTranscript.collectAsStateWithLifecycle()

    val listState = rememberLazyListState()

    // Fallback Intent-based speech recognizer launcher
    val speechIntentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
                ?.trim()
                .orEmpty()
            if (spoken.isNotEmpty()) {
                viewModel.updateInputText(spoken)
                viewModel.sendMessage(spoken)
            }
        }
    }

    // Runtime permission launcher for RECORD_AUDIO
    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.startVoiceListening()
        } else {
            // Try system speech intent or notify Boss that text mode is ready
            try {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "बोलिए Boss, RANI सुन रही है…")
                }
                speechIntentLauncher.launch(intent)
            } catch (_: Exception) {
                viewModel.updateInputText("Rani, kya kar rahi ho?")
            }
        }
    }

    val handleMicTrigger = {
        if (isListening) {
            viewModel.stopVoiceListening()
        } else {
            val hasPerm = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
            if (hasPerm) {
                viewModel.startVoiceListening()
            } else {
                audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    // Auto-scroll to latest message
    LaunchedEffect(messages.size, isThinking) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    if (activeSheet != QuickActionSheet.NONE) {
        BackHandler {
            viewModel.closeSheet()
        }
    }

    val pendingReminders = reminders.count { !it.isCompleted }
    val pendingTasks = planTasks.count { !it.isDone }

    val quickActions = listOf(
        QuickActionItem(
            label = stringResource(R.string.action_ask_rani),
            icon = Icons.Filled.AutoAwesome,
            sheet = QuickActionSheet.ASK_RANI,
            accent = RaniVibrantViolet,
            testTag = "quick_action_ask"
        ),
        QuickActionItem(
            label = stringResource(R.string.action_reminder),
            icon = Icons.Filled.NotificationsActive,
            sheet = QuickActionSheet.REMINDERS,
            accent = RaniGoldCrown,
            badge = if (pendingReminders > 0) "$pendingReminders" else null,
            testTag = "quick_action_reminder"
        ),
        QuickActionItem(
            label = stringResource(R.string.action_today_plan),
            icon = Icons.Filled.Schedule,
            sheet = QuickActionSheet.TODAY_PLAN,
            accent = RaniCyberCyan,
            badge = if (pendingTasks > 0) "$pendingTasks" else null,
            testTag = "quick_action_plan"
        ),
        QuickActionItem(
            label = stringResource(R.string.action_weather),
            icon = Icons.Filled.Cloud,
            sheet = QuickActionSheet.WEATHER,
            accent = RaniElectricBlue,
            badge = weatherSnapshot?.let { "${it.temperatureC.toInt()}°" },
            testTag = "quick_action_weather"
        ),
        QuickActionItem(
            label = stringResource(R.string.action_notes),
            icon = Icons.Filled.EventNote,
            sheet = QuickActionSheet.NOTES,
            accent = RaniRoyalPurple,
            badge = if (notes.isNotEmpty()) "${notes.size}" else null,
            testTag = "quick_action_notes"
        ),
        QuickActionItem(
            label = stringResource(R.string.action_search),
            icon = Icons.Filled.Search,
            sheet = QuickActionSheet.SEARCH,
            accent = RaniCyberCyan,
            testTag = "quick_action_search"
        ),
        QuickActionItem(
            label = stringResource(R.string.action_settings),
            icon = Icons.Filled.Settings,
            sheet = QuickActionSheet.SETTINGS,
            accent = RaniTextSecondary,
            testTag = "quick_action_settings"
        )
    )

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = RaniSpaceBlack,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            RaniSpaceBlack,
                            RaniDeepBackground,
                            Color(0xFF0E0620)
                        )
                    )
                )
                .drawBehind {
                    // Ambient futuristic purple and blue glowing nebula lights
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                RaniRoyalPurple.copy(alpha = if (highGlow) 0.22f else 0.12f),
                                Color.Transparent
                            ),
                            center = Offset(size.width * 0.2f, size.height * 0.18f),
                            radius = size.minDimension * 0.65f
                        ),
                        center = Offset(size.width * 0.2f, size.height * 0.18f),
                        radius = size.minDimension * 0.65f
                    )
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                RaniCyberCyan.copy(alpha = if (highGlow) 0.16f else 0.08f),
                                Color.Transparent
                            ),
                            center = Offset(size.width * 0.85f, size.height * 0.28f),
                            radius = size.minDimension * 0.55f
                        ),
                        center = Offset(size.width * 0.85f, size.height * 0.28f),
                        radius = size.minDimension * 0.55f
                    )
                }
                .padding(innerPadding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 680.dp)
                    .align(Alignment.TopCenter),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // 1. Futuristic Top Bar
                RaniTopHeaderBar(
                    voiceEnabled = voiceEnabled,
                    autoSpeak = autoSpeak,
                    isSpeaking = isSpeaking,
                    languagePref = languagePref,
                    onToggleAutoSpeak = { viewModel.toggleAutoSpeak() },
                    onStopSpeaking = { viewModel.stopSpeaking() },
                    onOpenSettings = { viewModel.openSheet(QuickActionSheet.SETTINGS) }
                )

                // 2. Animated RANI AI Avatar / Orb & Dynamic Boss Greeting
                RaniAiOrbSection(
                    greeting = viewModel.getDynamicGreeting(),
                    subGreeting = viewModel.getDynamicHindiSubGreeting(),
                    isListening = isListening,
                    isSpeaking = isSpeaking,
                    isThinking = isThinking,
                    voiceRmsLevel = voiceRms,
                    partialTranscript = partialTranscript,
                    highGlow = highGlow,
                    onOrbClick = {
                        if (isSpeaking) {
                            viewModel.stopSpeaking()
                        } else {
                            handleMicTrigger()
                        }
                    },
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )

                // 3. Quick Actions Row (All 7 Functional Buttons)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    quickActions.forEach { action ->
                        QuickActionPill(
                            item = action,
                            onClick = { viewModel.openSheet(action.sheet) }
                        )
                    }
                }

                // Optional Error / API Unavailable Card with Retry Button
                AnimatedVisibility(
                    visible = errorRetryState != null,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    errorRetryState?.let { errState ->
                        ErrorRetryBannerCard(
                            errorState = errState,
                            onRetry = { viewModel.retryLastMessage() },
                            onDismiss = { viewModel.dismissErrorRetry() }
                        )
                    }
                }

                // Optional Status Banner (Voice / Action Notifications)
                AnimatedVisibility(
                    visible = statusBanner != null,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    statusBanner?.let { bannerText ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 4.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(RaniSurfaceElevated)
                                .border(1.dp, RaniCyberCyan.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = bannerText,
                                style = MaterialTheme.typography.bodySmall,
                                color = RaniCyberCyan,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { viewModel.dismissBanner() },
                                modifier = Modifier.size(26.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Close,
                                    contentDescription = "Dismiss",
                                    tint = RaniTextSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                // 4. Chat History (Interactive Boss <-> RANI Conversation)
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp)
                        .testTag("chat_history_list"),
                    contentPadding = PaddingValues(vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(messages, key = { it.id }) { msg ->
                        ChatBubbleItem(
                            message = msg,
                            onSpeakClick = { viewModel.speakMessage(msg.message) }
                        )
                    }

                    if (isThinking) {
                        item {
                            RaniThinkingIndicator()
                        }
                    }
                }

                // 5. Bottom Input Bar (Text Input + Microphone Button + Send Button)
                RaniCommandInputBar(
                    inputText = inputText,
                    onInputChange = { viewModel.updateInputText(it) },
                    isListening = isListening,
                    isThinking = isThinking,
                    onMicClick = handleMicTrigger,
                    onSendClick = {
                        focusManager.clearFocus()
                        viewModel.sendMessage()
                    }
                )
            }
        }

        // Modal Bottom Sheets for All 7 Quick Actions
        if (activeSheet != QuickActionSheet.NONE) {
            val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
            ModalBottomSheet(
                onDismissRequest = { viewModel.closeSheet() },
                sheetState = sheetState,
                containerColor = RaniSurfaceDark,
                scrimColor = Color.Black.copy(alpha = 0.72f),
                shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
            ) {
                when (activeSheet) {
                    QuickActionSheet.ASK_RANI -> AskRaniSheetContent(
                        onSelectPrompt = { prompt -> viewModel.sendMessage(prompt) },
                        onClose = { viewModel.closeSheet() }
                    )

                    QuickActionSheet.REMINDERS -> ReminderSheetContent(
                        reminders = reminders,
                        onAddReminder = { title, time -> viewModel.addReminder(title, time) },
                        onToggleReminder = { rem -> viewModel.toggleReminder(rem) },
                        onDeleteReminder = { id -> viewModel.deleteReminder(id) },
                        onAskRaniBriefing = {
                            viewModel.sendMessage("Rani, mere active reminders kya hain?")
                        },
                        onClose = { viewModel.closeSheet() }
                    )

                    QuickActionSheet.TODAY_PLAN -> TodayPlanSheetContent(
                        tasks = planTasks,
                        onAddTask = { title, slot, prio -> viewModel.addPlanTask(title, slot, prio) },
                        onToggleTask = { task -> viewModel.togglePlanTask(task) },
                        onDeleteTask = { id -> viewModel.deletePlanTask(id) },
                        onAskRaniOptimize = {
                            viewModel.sendMessage("Rani, aaj ke mere plan aur tasks ko dekh kar best productivity tip do.")
                        },
                        onClose = { viewModel.closeSheet() }
                    )

                    QuickActionSheet.WEATHER -> WeatherSheetContent(
                        weather = weatherSnapshot,
                        isLoading = isWeatherLoading,
                        error = weatherError,
                        presetCities = viewModel.presetCities,
                        onSelectPresetCity = { city -> viewModel.loadPresetCityWeather(city) },
                        onSearchCity = { q -> viewModel.searchCityWeather(q) },
                        onAskRaniWeatherBriefing = {
                            viewModel.sendMessage("Rani, aaj ka weather kaisa hai aur mujhe kya dhyan rakhna chahiye?")
                        },
                        onClose = { viewModel.closeSheet() }
                    )

                    QuickActionSheet.NOTES -> NotesSheetContent(
                        notes = notes,
                        onAddNote = { title, content, cat -> viewModel.addNote(title, content, cat) },
                        onDeleteNote = { id -> viewModel.deleteNote(id) },
                        onAskRaniSummarizeNote = { note ->
                            viewModel.sendMessage("Rani, mere is note ka short summary aur action items batao: \"${note.title} - ${note.content}\"")
                        },
                        onClose = { viewModel.closeSheet() }
                    )

                    QuickActionSheet.SEARCH -> SearchSheetContent(
                        query = searchQuery,
                        onQueryChange = { viewModel.updateSearchQuery(it) },
                        messages = messages,
                        reminders = reminders,
                        tasks = planTasks,
                        notes = notes,
                        onAskRaniSearch = { queryPrompt -> viewModel.sendMessage(queryPrompt) },
                        onClose = { viewModel.closeSheet() }
                    )

                    QuickActionSheet.SETTINGS -> SettingsSheetContent(
                        voiceEnabled = voiceEnabled,
                        onVoiceEnabledChange = { viewModel.setVoiceEnabled(it) },
                        autoSpeakEnabled = autoSpeak,
                        onToggleAutoSpeak = { viewModel.toggleAutoSpeak() },
                        speechRate = speechRate,
                        onSpeechRateChange = { viewModel.setSpeechRateValue(it) },
                        languagePreference = languagePref,
                        onLanguageChange = { viewModel.setLanguagePreference(it) },
                        highGlowEnabled = highGlow,
                        onHighGlowChange = { viewModel.setHighGlowIntensity(it) },
                        isGeminiKeyConfigured = viewModel.isGeminiKeyConfigured(),
                        messageCount = messages.size,
                        onTestVoiceSample = {
                            viewModel.speakMessage("Boss, RANI का वॉइस सिस्टम बिल्कुल तैयार है!")
                        },
                        onResetSampleConversation = { viewModel.resetToSampleConversation() },
                        onClearChatHistory = { viewModel.clearChatHistory() },
                        onClose = { viewModel.closeSheet() }
                    )

                    QuickActionSheet.NONE -> {}
                }
            }
        }
    }
}

@Composable
private fun ErrorRetryBannerCard(
    errorState: ErrorRetryState,
    onRetry: () -> Unit,
    onDismiss: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(RaniSurfaceElevated)
            .border(1.dp, RaniGoldCrown.copy(alpha = 0.65f), RoundedCornerShape(14.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .testTag("error_retry_banner"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Icon(
            imageVector = Icons.Filled.WarningAmber,
            contentDescription = null,
            tint = RaniGoldCrown,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = errorState.message,
            style = MaterialTheme.typography.bodySmall,
            color = RaniTextPrimary,
            modifier = Modifier.weight(1f)
        )
        if (errorState.canRetry) {
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = onRetry,
                colors = ButtonDefaults.buttonColors(containerColor = RaniRoyalPurple),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .height(34.dp)
                    .testTag("retry_network_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.Refresh,
                    contentDescription = "Retry",
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("Retry", style = MaterialTheme.typography.labelSmall)
            }
        }
        IconButton(
            onClick = onDismiss,
            modifier = Modifier.size(28.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.Close,
                contentDescription = "Dismiss",
                tint = RaniTextSecondary,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
private fun RaniTopHeaderBar(
    voiceEnabled: Boolean,
    autoSpeak: Boolean,
    isSpeaking: Boolean,
    languagePref: String,
    onToggleAutoSpeak: () -> Unit,
    onStopSpeaking: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Brand Badge
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(RaniSurfaceElevated.copy(alpha = 0.85f))
                .border(1.dp, RaniBorderGlow, RoundedCornerShape(50))
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Text(
                text = "👑 RANI",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = RaniTextPrimary
            )
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(RaniCyberCyan)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "BOSS EDITION • $languagePref",
                style = MaterialTheme.typography.labelSmall,
                color = RaniCyberCyan
            )
        }

        // Voice / Settings Controls
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (isSpeaking) {
                IconButton(
                    onClick = onStopSpeaking,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("stop_tts_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Stop,
                        contentDescription = "Stop Speaking",
                        tint = RaniNeonPink
                    )
                }
            }

            IconButton(
                onClick = onToggleAutoSpeak,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("tts_toggle_button")
            ) {
                Icon(
                    imageVector = if (voiceEnabled && autoSpeak) Icons.AutoMirrored.Filled.VolumeUp else Icons.AutoMirrored.Filled.VolumeOff,
                    contentDescription = stringResource(R.string.content_desc_tts),
                    tint = if (voiceEnabled && autoSpeak) RaniCyberCyan else RaniTextMuted
                )
            }

            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("top_settings_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.Settings,
                    contentDescription = stringResource(R.string.action_settings),
                    tint = RaniTextSecondary
                )
            }
        }
    }
}

@Composable
private fun QuickActionPill(
    item: QuickActionItem,
    onClick: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .height(48.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.horizontalGradient(
                    colors = listOf(
                        RaniSurfaceElevated,
                        RaniSurfaceDark
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(
                    colors = listOf(item.accent.copy(alpha = 0.65f), RaniBorderGlow)
                ),
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp)
            .testTag(item.testTag)
    ) {
        Icon(
            imageVector = item.icon,
            contentDescription = item.label,
            tint = item.accent,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = item.label,
            style = MaterialTheme.typography.labelLarge,
            color = RaniTextPrimary
        )
        if (item.badge != null) {
            Spacer(modifier = Modifier.width(6.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(item.accent.copy(alpha = 0.22f))
                    .padding(horizontal = 7.dp, vertical = 2.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = item.badge,
                    style = MaterialTheme.typography.labelSmall,
                    color = item.accent
                )
            }
        }
    }
}

@Composable
private fun ChatBubbleItem(
    message: ChatMessageEntity,
    onSpeakClick: () -> Unit
) {
    val isRani = message.sender == "RANI"
    val timeFormatted = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(message.timestamp))

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isRani) Arrangement.Start else Arrangement.End
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 310.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = 20.dp,
                        topEnd = 20.dp,
                        bottomStart = if (isRani) 4.dp else 20.dp,
                        bottomEnd = if (isRani) 20.dp else 4.dp
                    )
                )
                .background(
                    brush = if (isRani) {
                        Brush.linearGradient(
                            colors = listOf(
                                RaniSurfaceElevated,
                                Color(0xFF191038)
                            )
                        )
                    } else {
                        Brush.linearGradient(
                            colors = listOf(
                                RaniDeepViolet,
                                Color(0xFF3B1D7A)
                            )
                        )
                    }
                )
                .border(
                    width = 1.dp,
                    brush = if (isRani) {
                        Brush.linearGradient(listOf(RaniCyberCyan.copy(alpha = 0.5f), RaniRoyalPurple.copy(alpha = 0.4f)))
                    } else {
                        Brush.linearGradient(listOf(RaniVibrantViolet.copy(alpha = 0.6f), RaniElectricBlue.copy(alpha = 0.4f)))
                    },
                    shape = RoundedCornerShape(
                        topStart = 20.dp,
                        topEnd = 20.dp,
                        bottomStart = if (isRani) 4.dp else 20.dp,
                        bottomEnd = if (isRani) 20.dp else 4.dp
                    )
                )
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (isRani) "RANI 👑" else "BOSS",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = if (isRani) RaniCyberCyan else RaniGoldCrown
                    )
                    if (message.actionTag != null) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "• ${message.actionTag} SAVED",
                            style = MaterialTheme.typography.labelSmall,
                            color = RaniVibrantViolet
                        )
                    }
                }

                if (isRani) {
                    IconButton(
                        onClick = onSpeakClick,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = "Speak RANI response",
                            tint = RaniCyberCyan,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = message.message,
                style = MaterialTheme.typography.bodyLarge,
                color = RaniTextPrimary
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = timeFormatted,
                style = MaterialTheme.typography.labelSmall,
                color = RaniTextMuted,
                modifier = Modifier.align(Alignment.End)
            )
        }
    }
}

@Composable
private fun RaniThinkingIndicator() {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(18.dp))
            .background(RaniSurfaceElevated)
            .border(1.dp, RaniCyberCyan.copy(alpha = 0.45f), RoundedCornerShape(18.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .testTag("rani_thinking_indicator")
    ) {
        CircularProgressIndicator(
            color = RaniCyberCyan,
            strokeWidth = 2.dp,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = "RANI आपके लिए जवाब तैयार कर रही है, Boss…",
            style = MaterialTheme.typography.bodySmall,
            color = RaniCyberCyan
        )
    }
}

@Composable
private fun RaniCommandInputBar(
    inputText: String,
    onInputChange: (String) -> Unit,
    isListening: Boolean,
    isThinking: Boolean,
    onMicClick: () -> Unit,
    onSendClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .imePadding()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(RaniSurfaceElevated.copy(alpha = 0.95f))
            .border(
                width = 1.2.dp,
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        if (isListening) RaniNeonPink else RaniRoyalPurple,
                        RaniCyberCyan
                    )
                ),
                shape = RoundedCornerShape(26.dp)
            )
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Microphone Button (Min 48.dp touch target)
        IconButton(
            onClick = onMicClick,
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(
                    if (isListening) {
                        Brush.linearGradient(listOf(RaniNeonPink, RaniRoyalPurple))
                    } else {
                        Brush.linearGradient(listOf(RaniSurfaceDark, RaniSurfaceElevated))
                    }
                )
                .border(
                    width = 1.dp,
                    color = if (isListening) RaniNeonPink else RaniCyberCyan.copy(alpha = 0.6f),
                    shape = CircleShape
                )
                .testTag("mic_button")
        ) {
            Icon(
                imageVector = Icons.Filled.Mic,
                contentDescription = stringResource(R.string.content_desc_mic),
                tint = if (isListening) Color.White else RaniCyberCyan
            )
        }

        Spacer(modifier = Modifier.width(6.dp))

        // Text Input
        OutlinedTextField(
            value = inputText,
            onValueChange = onInputChange,
            placeholder = {
                Text(
                    text = if (isListening) "बोलिए Boss, RANI सुन रही है…" else stringResource(R.string.input_placeholder),
                    style = MaterialTheme.typography.bodyMedium,
                    color = RaniTextMuted
                )
            },
            maxLines = 3,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { onSendClick() }),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color.Transparent,
                unfocusedContainerColor = Color.Transparent,
                focusedBorderColor = Color.Transparent,
                unfocusedBorderColor = Color.Transparent,
                focusedTextColor = RaniTextPrimary,
                unfocusedTextColor = RaniTextPrimary,
                cursorColor = RaniCyberCyan
            ),
            modifier = Modifier
                .weight(1f)
                .testTag("chat_input_field")
        )

        Spacer(modifier = Modifier.width(6.dp))

        // Send Button (Min 48.dp touch target)
        val canSend = inputText.isNotBlank() && !isThinking
        IconButton(
            onClick = onSendClick,
            enabled = canSend,
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(
                    if (canSend) {
                        Brush.linearGradient(listOf(RaniRoyalPurple, RaniElectricBlue))
                    } else {
                        Brush.linearGradient(listOf(RaniSurfaceDark, RaniSurfaceDark))
                    }
                )
                .border(
                    width = 1.dp,
                    color = if (canSend) RaniCyberCyan else RaniBorderGlow,
                    shape = CircleShape
                )
                .testTag("send_button")
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.Send,
                contentDescription = stringResource(R.string.content_desc_send),
                tint = if (canSend) Color.White else RaniTextMuted
            )
        }
    }
}
