package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.RaniOrbState
import com.example.ui.theme.RaniCyberCyan
import com.example.ui.theme.RaniElectricBlue
import com.example.ui.theme.RaniGoldCrown
import com.example.ui.theme.RaniNeonPink
import com.example.ui.theme.RaniRoyalPurple
import com.example.ui.theme.RaniSurfaceElevated
import com.example.ui.theme.RaniTextPrimary
import com.example.ui.theme.RaniTextSecondary
import com.example.ui.theme.RaniVibrantViolet
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun RaniAiOrbSection(
    greeting: String,
    subGreeting: String,
    isListening: Boolean,
    isSpeaking: Boolean,
    isThinking: Boolean,
    voiceRmsLevel: Float,
    partialTranscript: String,
    highGlow: Boolean,
    onOrbClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val orbState = when {
        isListening -> RaniOrbState.LISTENING
        isThinking -> RaniOrbState.THINKING
        isSpeaking -> RaniOrbState.SPEAKING
        else -> RaniOrbState.IDLE
    }

    val infiniteTransition = rememberInfiniteTransition(label = "rani_orb_transition")

    val primaryRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (orbState) {
                    RaniOrbState.THINKING -> 2600
                    RaniOrbState.LISTENING -> 4200
                    RaniOrbState.SPEAKING -> 5000
                    RaniOrbState.IDLE -> 11000
                },
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "primary_rotation"
    )

    val counterRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (orbState) {
                    RaniOrbState.THINKING -> 2000
                    RaniOrbState.SPEAKING -> 3200
                    RaniOrbState.LISTENING -> 3800
                    RaniOrbState.IDLE -> 8500
                },
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "counter_rotation"
    )

    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_phase"
    )

    val sonarExpansion by infiniteTransition.animateFloat(
        initialValue = 0.65f,
        targetValue = 1.18f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "sonar_expansion"
    )

    val breathingPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = when (orbState) {
            RaniOrbState.LISTENING -> 1.14f
            RaniOrbState.SPEAKING -> 1.12f
            RaniOrbState.THINKING -> 1.09f
            RaniOrbState.IDLE -> 1.04f
        },
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (orbState) {
                    RaniOrbState.LISTENING, RaniOrbState.SPEAKING -> 550
                    RaniOrbState.THINKING -> 750
                    RaniOrbState.IDLE -> 2200
                },
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breathing_pulse"
    )

    val dynamicScale = if (orbState == RaniOrbState.LISTENING) {
        (breathingPulse + voiceRmsLevel * 0.18f).coerceAtMost(1.26f)
    } else {
        breathingPulse
    }

    val primaryAccent by animateColorAsState(
        targetValue = when (orbState) {
            RaniOrbState.LISTENING -> RaniNeonPink
            RaniOrbState.SPEAKING -> RaniCyberCyan
            RaniOrbState.THINKING -> RaniGoldCrown
            RaniOrbState.IDLE -> RaniRoyalPurple
        },
        animationSpec = tween(400),
        label = "primary_accent"
    )

    val secondaryAccent by animateColorAsState(
        targetValue = when (orbState) {
            RaniOrbState.LISTENING -> RaniVibrantViolet
            RaniOrbState.SPEAKING -> RaniRoyalPurple
            RaniOrbState.THINKING -> RaniCyberCyan
            RaniOrbState.IDLE -> RaniCyberCyan
        },
        animationSpec = tween(400),
        label = "secondary_accent"
    )

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(160.dp)
                .testTag("rani_ai_orb")
                .clickable(onClick = onOrbClick),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(160.dp)) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val maxRadius = size.minDimension / 2f

                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            primaryAccent.copy(alpha = if (highGlow) 0.50f else 0.30f),
                            secondaryAccent.copy(alpha = if (highGlow) 0.25f else 0.12f),
                            Color.Transparent
                        ),
                        center = center,
                        radius = maxRadius * dynamicScale
                    ),
                    radius = maxRadius * dynamicScale,
                    center = center
                )

                when (orbState) {
                    RaniOrbState.LISTENING -> {
                        val sonarAlpha = (1.18f - sonarExpansion).coerceIn(0f, 0.7f)
                        drawCircle(
                            color = RaniNeonPink.copy(alpha = sonarAlpha),
                            radius = maxRadius * sonarExpansion,
                            center = center,
                            style = Stroke(width = 2.5.dp.toPx())
                        )
                        drawCircle(
                            color = RaniCyberCyan.copy(alpha = sonarAlpha * 0.7f),
                            radius = maxRadius * ((sonarExpansion + 0.15f).coerceAtMost(1.22f)),
                            center = center,
                            style = Stroke(width = 1.5.dp.toPx())
                        )
                    }

                    RaniOrbState.THINKING -> {
                        for (i in 0 until 8) {
                            val angleRad = Math.toRadians((primaryRotation * 1.4 + i * 45.0))
                            val nodeRadius = maxRadius * (0.84f + 0.06f * sin(wavePhase + i))
                            val nx = center.x + (nodeRadius * cos(angleRad)).toFloat()
                            val ny = center.y + (nodeRadius * sin(angleRad)).toFloat()
                            drawCircle(
                                color = if (i % 2 == 0) RaniGoldCrown else RaniCyberCyan,
                                radius = 4.dp.toPx(),
                                center = Offset(nx, ny)
                            )
                        }
                    }

                    RaniOrbState.SPEAKING -> {
                        for (i in 0 until 12) {
                            val angleRad = Math.toRadians((i * 30.0 + primaryRotation * 0.5))
                            val waveAmp = 6.dp.toPx() * abs(sin(wavePhase + i * 0.6f))
                            val rStart = maxRadius * 0.78f
                            val rEnd = rStart + waveAmp + 5.dp.toPx()
                            val startPt = Offset(
                                center.x + (rStart * cos(angleRad)).toFloat(),
                                center.y + (rStart * sin(angleRad)).toFloat()
                            )
                            val endPt = Offset(
                                center.x + (rEnd * cos(angleRad)).toFloat(),
                                center.y + (rEnd * sin(angleRad)).toFloat()
                            )
                            drawLine(
                                color = if (i % 2 == 0) RaniCyberCyan else RaniVibrantViolet,
                                start = startPt,
                                end = endPt,
                                strokeWidth = 3.dp.toPx(),
                                cap = StrokeCap.Round
                            )
                        }
                    }

                    RaniOrbState.IDLE -> {
                        for (i in 0 until 4) {
                            val angleRad = Math.toRadians((primaryRotation + i * 90.0))
                            val orbitR = maxRadius * 0.82f
                            val px = center.x + (orbitR * cos(angleRad)).toFloat()
                            val py = center.y + (orbitR * sin(angleRad)).toFloat()
                            drawCircle(
                                color = if (i % 2 == 0) RaniCyberCyan else RaniVibrantViolet,
                                radius = 3.5.dp.toPx(),
                                center = Offset(px, py)
                            )
                        }
                    }
                }

                rotate(degrees = primaryRotation, pivot = center) {
                    for (i in 0 until 6) {
                        drawArc(
                            brush = Brush.sweepGradient(
                                listOf(primaryAccent, secondaryAccent, primaryAccent)
                            ),
                            startAngle = i * 60f + 8f,
                            sweepAngle = 36f,
                            useCenter = false,
                            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round),
                            topLeft = Offset(center.x - maxRadius * 0.86f, center.y - maxRadius * 0.86f),
                            size = Size(maxRadius * 1.72f, maxRadius * 1.72f)
                        )
                    }
                }

                rotate(degrees = counterRotation, pivot = center) {
                    drawArc(
                        color = secondaryAccent.copy(alpha = 0.85f),
                        startAngle = 20f,
                        sweepAngle = 140f,
                        useCenter = false,
                        style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round),
                        topLeft = Offset(center.x - maxRadius * 0.74f, center.y - maxRadius * 0.74f),
                        size = Size(maxRadius * 1.48f, maxRadius * 1.48f)
                    )
                    drawArc(
                        color = primaryAccent.copy(alpha = 0.85f),
                        startAngle = 200f,
                        sweepAngle = 140f,
                        useCenter = false,
                        style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round),
                        topLeft = Offset(center.x - maxRadius * 0.74f, center.y - maxRadius * 0.74f),
                        size = Size(maxRadius * 1.48f, maxRadius * 1.48f)
                    )
                }
            }

            Box(
                modifier = Modifier
                    .size(98.dp)
                    .scale(dynamicScale * 0.96f)
                    .clip(CircleShape)
                    .border(
                        width = 2.5.dp,
                        brush = Brush.linearGradient(
                            colors = listOf(primaryAccent, secondaryAccent, RaniElectricBlue)
                        ),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_rani_avatar_1790397357426),
                    contentDescription = stringResource(id = R.string.content_desc_orb),
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(98.dp)
                )

                if (orbState != RaniOrbState.IDLE) {
                    Box(
                        modifier = Modifier
                            .size(98.dp)
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(
                                        primaryAccent.copy(alpha = 0.36f),
                                        Color.Transparent
                                    )
                                )
                            ),
                        contentAlignment = Alignment.BottomCenter
                    ) {
                        if (orbState == RaniOrbState.LISTENING || orbState == RaniOrbState.SPEAKING) {
                            OrbEqualizerBars(
                                wavePhase = wavePhase,
                                rmsBoost = if (orbState == RaniOrbState.LISTENING) voiceRmsLevel else 0.55f,
                                barColor = if (orbState == RaniOrbState.LISTENING) RaniNeonPink else RaniCyberCyan,
                                modifier = Modifier
                                    .padding(bottom = 12.dp)
                                    .width(54.dp)
                                    .height(22.dp)
                            )
                        }
                    }
                }
            }
        }

        val statusLabel = when (orbState) {
            RaniOrbState.LISTENING -> if (partialTranscript.isNotBlank()) "सुन रही हूँ: \"$partialTranscript\"" else "LISTENING TO BOSS… (बोलिए Boss)"
            RaniOrbState.SPEAKING -> "SPEAKING TO BOSS… (रोकने के लिए टैप करें)"
            RaniOrbState.THINKING -> "THINKING FOR BOSS… (न्यूरल विश्लेषण जारी)"
            RaniOrbState.IDLE -> "RANI AI • TAP ORB TO SPEAK, BOSS"
        }

        AnimatedContent(
            targetState = statusLabel,
            transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(180)) },
            label = "orb_status_pill"
        ) { currentLabel ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(RaniSurfaceElevated.copy(alpha = 0.92f))
                    .border(
                        width = 1.dp,
                        color = primaryAccent.copy(alpha = 0.65f),
                        shape = RoundedCornerShape(50)
                    )
                    .clickable(onClick = onOrbClick)
                    .padding(horizontal = 14.dp, vertical = 5.dp)
                    .testTag("orb_state_pill")
            ) {
                Icon(
                    imageVector = when (orbState) {
                        RaniOrbState.LISTENING -> Icons.Filled.Mic
                        RaniOrbState.SPEAKING -> Icons.Filled.GraphicEq
                        RaniOrbState.THINKING -> Icons.Filled.Psychology
                        RaniOrbState.IDLE -> Icons.Filled.AutoAwesome
                    },
                    contentDescription = null,
                    tint = primaryAccent,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = currentLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = RaniTextPrimary,
                    maxLines = 1
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = greeting,
            style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 23.sp
            ),
            color = RaniTextPrimary,
            modifier = Modifier.testTag("boss_greeting_text")
        )

        Spacer(modifier = Modifier.height(2.dp))

        Text(
            text = subGreeting,
            style = MaterialTheme.typography.bodySmall,
            color = RaniTextSecondary
        )
    }
}

@Composable
private fun OrbEqualizerBars(
    wavePhase: Float,
    rmsBoost: Float,
    barColor: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val barCount = 7
        val spacing = size.width / (barCount * 2f)
        val barWidth = spacing * 1.1f
        for (i in 0 until barCount) {
            val factor = abs(sin(wavePhase + i * 0.75f))
            val heightRatio = (0.25f + factor * (0.45f + rmsBoost * 0.3f)).coerceIn(0.2f, 1f)
            val barHeight = size.height * heightRatio
            val left = i * (barWidth + spacing * 0.8f)
            val top = (size.height - barHeight) / 2f
            drawRoundRect(
                color = barColor,
                topLeft = Offset(left, top),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
            )
        }
    }
}
