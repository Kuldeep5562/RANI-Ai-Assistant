package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.util.DetectedLanguage
import com.example.util.LanguageDetector
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID

class RaniVoiceManager(
    private val context: Context,
    private val onSpeechResult: (String) -> Unit,
    private val onVoiceNotice: (String) -> Unit
) {
    private val mainHandler = Handler(Looper.getMainLooper())

    private var tts: TextToSpeech? = null
    private var isTtsInitialized = false
    private var speechRecognizer: SpeechRecognizer? = null

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _voiceRmsLevel = MutableStateFlow(0f)
    val voiceRmsLevel: StateFlow<Float> = _voiceRmsLevel.asStateFlow()

    private val _partialTranscript = MutableStateFlow("")
    val partialTranscript: StateFlow<String> = _partialTranscript.asStateFlow()

    private val _isVoiceRecognitionSupported = MutableStateFlow(true)
    val isVoiceRecognitionSupported: StateFlow<Boolean> = _isVoiceRecognitionSupported.asStateFlow()

    private val _isTtsAvailable = MutableStateFlow(false)
    val isTtsAvailable: StateFlow<Boolean> = _isTtsAvailable.asStateFlow()

    var voiceMasterEnabled: Boolean = true
    var speechRate: Float = 1.0f
    var speechPitch: Float = 1.05f

    init {
        initTextToSpeech()
        checkSpeechAvailability()
    }

    private fun checkSpeechAvailability() {
        val available = try {
            SpeechRecognizer.isRecognitionAvailable(context)
        } catch (_: Exception) {
            false
        }
        _isVoiceRecognitionSupported.value = available
    }

    private fun initTextToSpeech() {
        try {
            tts = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    isTtsInitialized = true
                    _isTtsAvailable.value = true
                    val hiLocale = Locale.forLanguageTag("hi-IN")
                    val inLocale = Locale.forLanguageTag("en-IN")
                    val result = tts?.setLanguage(hiLocale)
                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        tts?.setLanguage(inLocale)
                    }
                    tts?.setPitch(speechPitch)
                    tts?.setSpeechRate(speechRate)
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {
                            _isSpeaking.value = true
                        }

                        override fun onDone(utteranceId: String?) {
                            _isSpeaking.value = false
                        }

                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) {
                            _isSpeaking.value = false
                        }

                        override fun onError(utteranceId: String?, errorCode: Int) {
                            _isSpeaking.value = false
                        }
                    })
                } else {
                    isTtsInitialized = false
                    _isTtsAvailable.value = false
                }
            }
        } catch (_: Exception) {
            isTtsInitialized = false
            _isTtsAvailable.value = false
        }
    }

    fun speak(text: String, preferredLanguage: String = "Auto") {
        if (!voiceMasterEnabled || !isTtsInitialized || tts == null) {
            return
        }
        val cleanForSpeech = text
            .replace(Regex("""[👑😊🚀🎉📝☀️⛅☁️🌫️🌦️🌧️❄️⛈️🌤️🔥⚡⏰•*]"""), "")
            .trim()
        if (cleanForSpeech.isEmpty()) return

        val detected = LanguageDetector.detect(cleanForSpeech, preferredLanguage)
        val primaryLocale = when (detected) {
            DetectedLanguage.HINDI -> Locale.forLanguageTag("hi-IN")
            DetectedLanguage.HINGLISH -> Locale.forLanguageTag("en-IN")
            DetectedLanguage.ENGLISH -> Locale.forLanguageTag("en-US")
        }

        val langSupport = tts?.isLanguageAvailable(primaryLocale) ?: TextToSpeech.LANG_NOT_SUPPORTED
        if (langSupport >= TextToSpeech.LANG_AVAILABLE) {
            tts?.language = primaryLocale
        } else {
            val fallbackIn = Locale.forLanguageTag("en-IN")
            if ((tts?.isLanguageAvailable(fallbackIn) ?: -1) >= TextToSpeech.LANG_AVAILABLE) {
                tts?.language = fallbackIn
            } else {
                tts?.language = Locale.US
            }
        }

        tts?.setPitch(speechPitch)
        tts?.setSpeechRate(speechRate)

        val utteranceId = UUID.randomUUID().toString()
        _isSpeaking.value = true
        val speakResult = tts?.speak(cleanForSpeech, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        if (speakResult == TextToSpeech.ERROR) {
            _isSpeaking.value = false
        }
    }

    fun stopSpeaking() {
        try {
            tts?.stop()
        } catch (_: Exception) {
        }
        _isSpeaking.value = false
    }

    fun startListening(languagePref: String = "Auto") {
        stopSpeaking()
        mainHandler.post {
            if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                _isVoiceRecognitionSupported.value = false
                onVoiceNotice("Boss, इस डिवाइस/एम्युलेटर पर वॉइस इंजन उपलब्ध नहीं है। Text Mode सक्रिय है।")
                return@post
            }

            try {
                if (speechRecognizer == null) {
                    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
                    speechRecognizer?.setRecognitionListener(createRecognitionListener())
                }

                val langTag = when (languagePref) {
                    "Hindi" -> "hi-IN"
                    "English" -> "en-US"
                    else -> "en-IN"
                }

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, langTag)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                }

                _partialTranscript.value = ""
                _isListening.value = true
                speechRecognizer?.startListening(intent)
            } catch (_: Exception) {
                _isListening.value = false
                onVoiceNotice("Boss, माइक्रोफ़ोन शुरू नहीं हो सका। आप नीचे टेक्स्ट में कमांड दे सकते हैं।")
            }
        }
    }

    fun stopListening() {
        mainHandler.post {
            try {
                speechRecognizer?.stopListening()
            } catch (_: Exception) {
            }
            _isListening.value = false
            _voiceRmsLevel.value = 0f
        }
    }

    private fun createRecognitionListener(): RecognitionListener {
        return object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                _isListening.value = true
            }

            override fun onBeginningOfSpeech() {
                _isListening.value = true
            }

            override fun onRmsChanged(rmsdB: Float) {
                val normalized = ((rmsdB + 2f) / 12f).coerceIn(0.08f, 1f)
                _voiceRmsLevel.value = normalized
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                _isListening.value = false
                _voiceRmsLevel.value = 0f
            }

            override fun onError(error: Int) {
                _isListening.value = false
                _voiceRmsLevel.value = 0f
                val msg = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Boss, आपकी आवाज़ स्पष्ट नहीं सुनाई दी। फिर से माइक या ऑर्ब पर टैप करें या टेक्स्ट लिखें।"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Boss, कृपया माइक्रोफ़ोन की अनुमति (Permission) दें।"
                    else -> "Boss, वॉइस इनपुट उपलब्ध नहीं हो पाया — Text Mode तैयार है।"
                }
                onVoiceNotice(msg)
            }

            override fun onResults(results: Bundle?) {
                _isListening.value = false
                _voiceRmsLevel.value = 0f
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val spoken = matches?.firstOrNull()?.trim().orEmpty()
                _partialTranscript.value = ""
                if (spoken.isNotEmpty()) {
                    onSpeechResult(spoken)
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val partial = matches?.firstOrNull()?.trim().orEmpty()
                if (partial.isNotEmpty()) {
                    _partialTranscript.value = partial
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
    }

    fun release() {
        mainHandler.post {
            try {
                speechRecognizer?.destroy()
                speechRecognizer = null
            } catch (_: Exception) {
            }
            try {
                tts?.stop()
                tts?.shutdown()
                tts = null
            } catch (_: Exception) {
            }
        }
    }
}
